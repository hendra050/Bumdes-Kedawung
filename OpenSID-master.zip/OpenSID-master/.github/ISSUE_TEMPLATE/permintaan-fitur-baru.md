---
name: Permintaan Fitur Baru
about: Mengusulkan fitur baru
title: ''
labels: Fitur
assignees: ''

---

**Apa kekurangan yg ingin diatasi?**
<!--
Beri keterangan singkat dan jelas mengapa fitur ini diperlukan. 
-->


**Jelaskan solusi yg diinginkan**
<!--
Beri keterangan singkat dan jelas mengenai fitur yg diinginkan.
Beri acuan peraturan yg mendasari fitur ini, kalau ada.
Lampirkan contoh laporan dan tampakan layar yg diinginkan. 
-->



**Apakah ada alternatif lain**
<!--
Beri keterangan singkat dan jelas solusi lain yg telah anda pertimbangkan untuk kebutuhan ini.
-->




**Untuk versi OpenSID mana**
<!--
Fitur ini diusulkan untuk versi Rilis Umum (mis. v21.03) atau Rilis Premium (mis v21.03-premium) yg mana?
-->



**Informasi tambahan**
<!--
Beri informasi lainnya yg dapat membantu menjelaskan permintaan ini.
-->
