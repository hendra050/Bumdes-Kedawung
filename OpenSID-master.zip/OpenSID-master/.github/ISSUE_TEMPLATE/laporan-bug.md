---
name: Laporan Bug
about: Laporan bug atau error
title: "[BUG] "
labels: bug
assignees: ''

---

**Jelaskan error yg dialami**
<!--
Harap tidak melaporkan masalah instal OpenSID. Masalah pada waktu install harap ditanyakan di https://www.facebook.com/groups/OpenSID atau di https://t.me/joinchat/SI0GWHeqKT39Gxhh, karena terkait sistem masing2 pengguna. 

Berikan keterangan yg jelas dan singkat mengenai error yg dialami. 
Pastikan error ini juga ditemukan di https://demo.opensid.or.id (untuk RIlis Umum) atau di https://berputar.opensid.or.id (untuk RIlis Premium).
-->



**Cara untuk mereplikasi errornya**
<!--
Langkah untuk mereplikasi error yg dialami, misalnya:
1. Pergi ke halaman '...'
2. Klik tombol '....'
3. Gulir ke bawah sampai '....'
4. Lihat error
-->


**Hasil yg diharapkan**
<!--
Berikan keterangan yg jelas dan singkat apa hasil yg diharapkan.
-->

**Tampakan layar dan log error**
<!--
Lampirkan tampakan layar yg menjelaskan permasalahan.
Lampirkan isi file di folder `logs` atau tampakan error di console inspector browser.
-->


**Versi OpenSID**
<!--
Error ini terjadi di rilis/versi berapa: Rilis umum (mis. v21.03) atau premium (v21.03-premium)?
-->


**Tema Yg Digunakan**
<!-- Sebutkan tema dan versinya yg digunakan -->



**Informasi tambahan**
<!--
Penjelasan lain yg dapat membantu.
-->
