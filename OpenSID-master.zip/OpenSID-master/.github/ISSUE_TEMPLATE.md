<!--
Harap diisi hanya untuk melaporakn bug atau permintaan penambahan fitur saja. Jika ada pertanyaan dukungan komunitas OpenSID sebaiknya posting di grup Facebook: https://www.facebook.com/groups/opensid
-->

### Bagaimana alurnya sampai muncul masalah?


### Seperti apa yang diharapkan?


### Apa yang terjadi?


### Informasi tambahan 

| Tanya            | Jawab
| ---------------- | ---
| Versi OpenSID    | 2.x
| Versi PHP        | 
| System operasi   |
