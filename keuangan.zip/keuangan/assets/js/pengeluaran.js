var deleteForm = document.querySelectorAll('.formDelete');

deleteForm.forEach((form) => {
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var currForm = this;
    var data2 = this.getAttribute("id-akun");
    Swal.fire({
      title: "Anda yakin?",
      html: `Data ini akan dihapus!`,
      // html: `Data <b>${data2}</b> akan dihapus!`,
      icon: "question",
      confirmButtonText: "Ya",
      showCancelButton: true,
      cancelButtonText: "Tidak",
    }).then((response) => {
      if (response.isConfirmed) {
        currForm.submit();
      }
    });
  });
});