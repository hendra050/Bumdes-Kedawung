-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Sep 2024 pada 07.55
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mahasiswa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `berita` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `judul`, `berita`, `created_at`, `updated_at`) VALUES
(1, 'Pedoman Akademik Universitas Narotama 2021', 'Dalam rangkan mendukung berlangsunya Tri Dharma perguruan tinggi, Universitas Narotama menerbitkan Pedoman Akademik yang dapat di unduh pada', '2021-07-04 23:22:16', '2021-07-04 23:27:44'),
(2, 'Peraturan rektor tentang Tugas Akhir', 'Berikut adalah Peraturan Rektor mengenai Pelaksanaan Tugas Akhir, Skripsi dan Tesis di lingkungan Universitas Narotama Surabaya Tahun 2018', '2021-07-04 23:27:09', '2021-07-04 23:27:09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `biodata`
--

CREATE TABLE `biodata` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `nim` int(255) NOT NULL,
  `id_dosen` int(255) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL DEFAULT 'assets/img/default.jpg',
  `jenis_kelamin` tinyint(4) NOT NULL DEFAULT 0,
  `tempat_lahir` varchar(64) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `golongan_darah` tinyint(4) NOT NULL DEFAULT 0,
  `agama` tinyint(4) NOT NULL DEFAULT 0,
  `alamat` text NOT NULL,
  `no_telepon` varchar(13) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0 = tidak aktif\r\n1 = aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `biodata`
--

INSERT INTO `biodata` (`id`, `id_user`, `nim`, `id_dosen`, `nama_lengkap`, `foto`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `golongan_darah`, `agama`, `alamat`, `no_telepon`, `status`, `created_at`, `updated_at`) VALUES
(4319029, 3, 1, 0, 'Super Admin', 'uploads/1625438851.jpg', 0, 'Tangerang', '2000-01-25', 0, 0, 'Sidoarjo', '04389', 1, '2021-06-30 15:06:04', '2024-07-16 04:39:51'),
(4319049, 38, 2, 0, 'Achmad Musyaffa Taufiqi', 'assets/img/default.jpg', 0, 'Tangerang', '2000-01-25', 0, 0, 'Sidoarjo', '089121313', 1, '2021-07-04 23:32:00', '2024-07-16 04:39:58'),
(4319082, 0, 0, 0, 'Nauli Aldreina', 'assets/img/default.jpg', 0, 'Sragen', '2003-11-11', 0, 0, 'Solo', '123456780', 1, '2024-07-18 07:13:52', '2024-07-18 07:13:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `coa`
--

CREATE TABLE `coa` (
  `id_akun` int(11) NOT NULL,
  `kode_akun` int(11) NOT NULL,
  `sub1_akun` int(11) NOT NULL,
  `sub2_akun` int(11) NOT NULL,
  `nama_akun` varchar(255) NOT NULL,
  `pencapaian` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `pos` enum('debit','kredit') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `coa`
--

INSERT INTO `coa` (`id_akun`, `kode_akun`, `sub1_akun`, `sub2_akun`, `nama_akun`, `pencapaian`, `tahun`, `jumlah`, `pos`) VALUES
(1, 1, 0, 0, 'Kas', 0, 0, 0, 'debit'),
(2, 1, 1, 0, 'Kas Besar', 10000, 2024, 1000000, 'debit'),
(3, 1, 2, 0, 'Kas Kecil', 0, 2024, 60000, 'debit'),
(4, 4, 0, 0, 'Pendapatan', 0, 0, 0, 'debit'),
(5, 4, 1, 0, 'Pendapatan Penjualan', 0, 0, 0, 'debit'),
(6, 4, 2, 0, 'Pendapatan Hadiah', 10000, 2024, 0, 'debit'),
(7, 5, 0, 0, 'Belanja', 0, 0, 0, 'debit'),
(9, 5, 2, 0, 'Belanja Barang', 0, 2024, 300000, 'debit'),
(10, 6, 0, 0, 'Biaya Usaha', 0, 2024, 0, 'debit'),
(11, 6, 1, 0, 'Biaya Gaji', 0, 2024, 0, 'debit'),
(12, 6, 2, 0, 'Biaya Gaji Bonus', 0, 2024, 0, 'debit'),
(13, 4, 3, 0, 'Pendapatan Jasa', 10000, 2024, 0, 'debit'),
(68, 4, 4, 0, 'Pendapatan Bonus', 0, 0, 0, 'debit'),
(416, 5, 1, 0, 'Belanja Gaji', 0, 0, 0, 'debit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurnal`
--

CREATE TABLE `jurnal` (
  `id_akun` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `uraian` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `pos_debit` varchar(255) NOT NULL,
  `pos_kredit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `jurnal`
--

INSERT INTO `jurnal` (`id_akun`, `tgl_transaksi`, `uraian`, `jumlah`, `pos_debit`, `pos_kredit`) VALUES
(7, '2024-08-17 00:00:00', 'coba', 500000, '9', '3'),
(9, '2024-08-10 00:00:00', 'gajian', 150000, '12', '2'),
(10, '2024-08-16 00:00:00', 'gaji karyawan', 200000, '11', '3'),
(11, '2024-08-15 00:00:00', 'paket', 100000, '9', '3'),
(12, '2024-09-01 00:00:00', 'gaji bulanan', 200000, '11', '2'),
(13, '2024-09-02 00:00:00', 'beli pakan ternak', 50000, '9', '3'),
(37, '2024-08-05 00:00:00', 'coba', 300000, '3', '6'),
(44, '2024-07-10 00:00:00', 'sponsor', 1500000, '2', '6'),
(48, '2024-08-15 00:00:00', 'hasil jual jasa', 600000, '3', '5'),
(51, '2024-08-15 00:00:00', 'Pendapatan Penjualan Ternak Ayam', 600000, '2', '5'),
(52, '2024-09-01 00:00:00', 'penjualan gorengan', 100000, '3', '5'),
(53, '2024-08-31 00:00:00', 'jual kursi', 200000, '3', '5'),
(56, '2024-09-07 00:00:00', 'Penjualan Motor', 5000000, '2', '5'),
(60, '2024-09-10 00:00:00', 'penjualan motor', 5000000, '2', '5'),
(61, '2024-09-10 00:00:00', 'transport', 50000, '10', '3'),
(63, '2024-09-11 00:00:00', 'penjualan laptop', 3000000, '2', '5'),
(64, '2024-09-12 00:00:00', 'penjualan hp', 2000000, '3', '5'),
(65, '2024-09-12 00:00:00', 'transport', 30000, '10', '3'),
(99, '2024-09-21 00:00:00', 'uji', 10000, '2', '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kode_akun`
--

CREATE TABLE `kode_akun` (
  `id` int(11) NOT NULL,
  `kode_akun` int(11) NOT NULL,
  `sub1_akun` int(11) NOT NULL,
  `sub2_akun` int(11) NOT NULL,
  `nama_akun` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `pos` enum('debit','kredit') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kode_akun`
--

INSERT INTO `kode_akun` (`id`, `kode_akun`, `sub1_akun`, `sub2_akun`, `nama_akun`, `jumlah`, `pos`) VALUES
(1, 1, 0, 0, 'Kas', 0, 'debit'),
(2, 1, 1, 0, 'Kas Besar', 1000000, 'debit'),
(3, 1, 2, 0, 'Kas Kecil', 500000, 'debit'),
(4, 4, 0, 0, 'Pendapatan', 0, 'debit'),
(5, 4, 1, 0, 'Pendapatan Penjualan', 500000, 'debit'),
(6, 4, 2, 0, 'Pendapatan Hadiah', 0, 'debit'),
(7, 5, 0, 0, 'Belanja', 0, 'debit'),
(8, 5, 1, 0, 'Belanja Gaji', 0, 'debit'),
(9, 5, 2, 0, 'Belanja Barang', 300000, 'debit'),
(10, 6, 0, 0, 'Biaya Usaha', 0, 'debit'),
(11, 6, 1, 0, 'Biaya Gaji', 0, 'debit'),
(12, 6, 2, 0, 'Biaya Gaji Bonus', 0, 'debit'),
(66, 4, 3, 0, 'Pendapatan Jasa', 0, 'debit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_dosen` int(11) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `id_user`, `id_dosen`, `id_prodi`, `semester`, `created_at`, `updated_at`) VALUES
(5, 38, 1, 1, 1, '2021-07-04 23:32:00', '2021-07-04 23:32:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mata_kuliah`
--

CREATE TABLE `mata_kuliah` (
  `id` int(11) NOT NULL,
  `nama_mata_kuliah` varchar(255) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `sks` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`id`, `nama_mata_kuliah`, `id_prodi`, `sks`, `semester`, `created_at`, `updated_at`) VALUES
(1, 'Basis Data', 2, 2, 1, '2021-06-22 03:44:09', '2021-07-04 22:28:21'),
(2, 'Algoritma Pemrograman', 1, 2, 1, '2021-06-22 03:44:09', '2021-06-22 03:44:09'),
(3, 'Desain dan Pemrograman Web', 1, 2, 1, '2021-07-04 11:47:59', '2021-07-04 11:47:59'),
(6, 'Desain Grafis', 2, 3, 1, '2021-07-04 23:31:25', '2021-07-04 23:31:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mutasi`
--

CREATE TABLE `mutasi` (
  `id_mutasi` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `uraian` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `pos_debit` varchar(255) NOT NULL,
  `pos_kredit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `mutasi`
--

INSERT INTO `mutasi` (`id_mutasi`, `tgl_transaksi`, `uraian`, `jumlah`, `pos_debit`, `pos_kredit`) VALUES
(1, '2024-09-21 00:00:00', 'uji', 10000, '2', '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemasukan`
--

CREATE TABLE `pemasukan` (
  `id_pemasukan` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `uraian` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `pos_debit` varchar(255) NOT NULL,
  `pos_kredit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pemasukan`
--

INSERT INTO `pemasukan` (`id_pemasukan`, `tgl_transaksi`, `uraian`, `jumlah`, `pos_debit`, `pos_kredit`) VALUES
(37, '2024-08-05 00:00:00', 'coba', 300000, '3', '6'),
(44, '2024-07-10 00:00:00', 'sponsor', 1500000, '2', '6'),
(48, '2024-08-15 00:00:00', 'hasil jual jasa', 600000, '3', '5'),
(51, '2024-08-15 00:00:00', 'Pendapatan Penjualan Ternak Ayam', 600000, '2', '5'),
(52, '2024-09-01 00:00:00', 'penjualan gorengan', 100000, '3', '5'),
(53, '2024-08-31 00:00:00', 'jual kursi', 200000, '3', '5'),
(56, '2024-09-07 00:00:00', 'Penjualan Motor', 5000000, '2', '5');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `jumlah` int(11) NOT NULL,
  `uraian` varchar(255) NOT NULL,
  `pos_debit` int(11) NOT NULL,
  `pos_kredit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengeluaran`
--

INSERT INTO `pengeluaran` (`id_pengeluaran`, `tgl_transaksi`, `jumlah`, `uraian`, `pos_debit`, `pos_kredit`) VALUES
(7, '2024-08-17 00:00:00', 500000, 'coba', 9, 3),
(9, '2024-08-10 00:00:00', 150000, 'gajian', 12, 2),
(10, '2024-08-16 00:00:00', 200000, 'gaji karyawan', 11, 3),
(11, '2024-08-15 00:00:00', 100000, 'paket', 9, 3),
(12, '2024-09-01 00:00:00', 200000, 'gaji bulanan', 11, 2),
(13, '2024-09-02 00:00:00', 50000, 'beli pakan ternak', 9, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `prodi`
--

CREATE TABLE `prodi` (
  `id` int(11) NOT NULL,
  `nama_prodi` varchar(64) NOT NULL,
  `id_fakultas` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `prodi`
--

INSERT INTO `prodi` (`id`, `nama_prodi`, `id_fakultas`, `created_at`, `updated_at`) VALUES
(1, 'Teknik Informatika', 1, '2021-06-21 09:32:52', '2021-06-21 09:32:52'),
(2, 'Sistem Informasi', 1, '2021-07-04 22:28:01', '2021-07-04 22:28:01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `nama_role` varchar(25) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `roles`
--

INSERT INTO `roles` (`id`, `nama_role`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2021-06-30 14:28:44', '2021-06-30 14:28:44'),
(2, 'mahasiswa', '2021-06-30 14:28:44', '2021-06-30 14:28:44'),
(3, 'dosen', '2021-06-30 14:28:50', '2021-06-30 14:28:50');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saldo`
--

CREATE TABLE `saldo` (
  `id_akun` int(11) NOT NULL,
  `kode_akun` int(11) NOT NULL,
  `sub1_akun` int(11) NOT NULL,
  `sub2_akun` int(11) NOT NULL,
  `nama_akun` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `pos` enum('debit','kredit') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `saldo`
--

INSERT INTO `saldo` (`id_akun`, `kode_akun`, `sub1_akun`, `sub2_akun`, `nama_akun`, `jumlah`, `pos`) VALUES
(1, 1, 0, 0, 'Kas', 0, 'debit'),
(2, 1, 1, 0, 'Kas Besar', 0, 'debit'),
(3, 1, 2, 0, 'Kas Kecil', 10000, 'debit'),
(4, 4, 0, 0, 'Pendapatan', 0, 'debit'),
(5, 4, 1, 0, 'Pendapatan Penjualan', 0, 'debit'),
(6, 4, 2, 0, 'Pendapatan Hadiah', 0, 'debit'),
(7, 5, 0, 0, 'Belanja', 0, 'debit'),
(8, 5, 1, 0, 'Belanja Gaji', 0, 'debit'),
(9, 5, 2, 0, 'Belanja Barang', 0, 'debit'),
(10, 6, 0, 0, 'Biaya Usaha', 0, 'debit'),
(11, 6, 1, 0, 'Biaya Gaji', 0, 'debit'),
(12, 6, 2, 0, 'Biaya Gaji Bonus', 0, 'debit'),
(13, 4, 3, 0, 'Pendapatan Jasa', 10000, 'kredit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_role` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `id_role`, `username`, `password`, `created_at`, `updated_at`) VALUES
(3, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2021-06-30 15:05:28', '2021-07-03 23:37:03'),
(38, 2, '04319023', '0344a49d08215c613d862c751323402a', '2021-07-04 23:32:00', '2021-07-04 23:32:00'),
(51, 2, '12220883', '47568d95c83a8e9320b3a49e020bc703', '2024-07-18 07:13:52', '2024-07-18 07:13:52');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `biodata`
--
ALTER TABLE `biodata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `coa`
--
ALTER TABLE `coa`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indeks untuk tabel `jurnal`
--
ALTER TABLE `jurnal`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indeks untuk tabel `kode_akun`
--
ALTER TABLE `kode_akun`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`,`id_dosen`,`id_prodi`),
  ADD KEY `id_dosen` (`id_dosen`),
  ADD KEY `id_prodi` (`id_prodi`);

--
-- Indeks untuk tabel `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_prodi` (`id_prodi`);

--
-- Indeks untuk tabel `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`id_mutasi`);

--
-- Indeks untuk tabel `pemasukan`
--
ALTER TABLE `pemasukan`
  ADD PRIMARY KEY (`id_pemasukan`);

--
-- Indeks untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indeks untuk tabel `prodi`
--
ALTER TABLE `prodi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_fakultas` (`id_fakultas`);

--
-- Indeks untuk tabel `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `saldo`
--
ALTER TABLE `saldo`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_role` (`id_role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `biodata`
--
ALTER TABLE `biodata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4319083;

--
-- AUTO_INCREMENT untuk tabel `coa`
--
ALTER TABLE `coa`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=417;

--
-- AUTO_INCREMENT untuk tabel `jurnal`
--
ALTER TABLE `jurnal`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT untuk tabel `kode_akun`
--
ALTER TABLE `kode_akun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=724;

--
-- AUTO_INCREMENT untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `mutasi`
--
ALTER TABLE `mutasi`
  MODIFY `id_mutasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pemasukan`
--
ALTER TABLE `pemasukan`
  MODIFY `id_pemasukan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `prodi`
--
ALTER TABLE `prodi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `saldo`
--
ALTER TABLE `saldo`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=601;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `mahasiswa_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mahasiswa_ibfk_2` FOREIGN KEY (`id_dosen`) REFERENCES `dosen` (`nip`),
  ADD CONSTRAINT `mahasiswa_ibfk_3` FOREIGN KEY (`id_prodi`) REFERENCES `prodi` (`id`);

--
-- Ketidakleluasaan untuk tabel `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD CONSTRAINT `mata_kuliah_ibfk_1` FOREIGN KEY (`id_prodi`) REFERENCES `prodi` (`id`);

--
-- Ketidakleluasaan untuk tabel `prodi`
--
ALTER TABLE `prodi`
  ADD CONSTRAINT `prodi_ibfk_1` FOREIGN KEY (`id_fakultas`) REFERENCES `fakultas` (`id`);

--
-- Ketidakleluasaan untuk tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_role`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
