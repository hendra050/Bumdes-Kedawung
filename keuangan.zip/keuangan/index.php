<?php
session_start();
if (!isset($_SESSION['id_user'])) {
  header("location: login.php");
}
include_once('./config/db.php');
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="./vendors/bootstrap-5.0.0-beta3-dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Style CSS -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- jQuery 3.6.0 -->
   <!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script defer src="./vendors/jQuery-3.6.0/jQuery.min.js"></script>
  <!-- Bootstrap Bundle with Popper -->
  <script defer src="./vendors/bootstrap-5.0.0-beta3-dist/js/bootstrap.bundle.min.js"></script>
  <!-- FontAwesome -->
  <script defer src="./vendors/fontawesome-free-5.15.3-web/js/all.min.js"></script>
  <!-- Script JS -->
  <script defer src="./assets/js/script.js"></script>
  <?php
  $page = @$_GET['page'];
  $action = @$_GET['action'];
  $file = '';
  $title = '';
  $script = '';
  if (isset($page)) {
    // ROUTE ADMIN
    if ($_SESSION['role'] == 'admin') {
      if ($page === '') {
        $file = 'admin/dashboard.php';
        $title = 'Dashboard - ';
      } else if ($page === 'pemasukan') {
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        if ($action === '') {
          $file = 'admin/pemasukan.php';
          $title = 'Data Transaksi Masuk - ';
          $script = '<script src="assets/js/pemasukan.js"></script>';
        } else if ($action === 'edit') {
          $file = 'admin/edit_pemasukan.php';
          $title = 'Edit Data Transaksi Masuk - ';
          $script = '<script src="assets/js/edit_pemasukan.js"></script>';
        } else if ($action === 'add') {
          $file = 'admin/add_pemasukan.php';
          $title = 'Tambah Data Transaksi Masuk - ';
          $script = '<script src="assets/js/add_pemasukan.js"></script>';
        } else if ($action === 'export') {
          $file = 'admin/export_pemasukan_excel.php';
          $title = 'Export Excel Pemasukan - ';
        } else {
          $file = 'admin/pemasukan.php';
          $title = 'Data Transaksi Masuk - ';
          $script = '<script src="assets/js/pemasukan.js"></script>';
        }
      } else if ($page === 'pengeluaran') {
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        if ($action === '') {
          $file = 'admin/pengeluaran.php';
          $title = 'Data Transaksi Keluar - ';
          $script = '<script src="assets/js/pengeluaran.js"></script>';
        } else if ($action === 'edit') {
          $file = 'admin/edit_pengeluaran.php';
          $title = 'Edit Data Transaksi Keluar - ';
          $script = '<script src="assets/js/edit_pengeluaran.js"></script>';
        } else if ($action === 'add') {
          $file = 'admin/add_pengeluaran.php';
          $title = 'Tambah Data Transaksi Keluar - ';
          $script = '<script src="assets/js/add_pengeluaran.js"></script>';
        } else if ($action === 'export') {
          $file = 'admin/export_pengeluaran_excel.php';
          $title = 'Export Excel Pengeluaran - ';
        } else {
          $file = 'admin/pengeluaran.php';
          $title = 'Data Transaksi Keluar - ';
          $script = '<script src="assets/js/pengeluaran.js"></script>';
        }
      } else if ($page === 'saldo') {
        $file = 'admin/saldo.php';
        $title = 'Saldo Awal - ';
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        if ($action === '') {
          $file = 'admin/saldo.php';
          $title = 'Saldo Awal - ';
        } else if ($action === 'edit') {
          $file = 'admin/edit_saldo.php';
          $title = 'Ubah Data Saldo - ';
          $script .= '<script src="assets/js/edit_fakultas.js"></script>';
        } else if ($action === 'add') {
          $file = 'admin/add_saldo.php';
          $title = 'Tambah Data Saldo Awal - ';
          $script = '<script src="assets/js/add_fakultas.js"></script>';
        } else {
          $file = 'admin/saldo.php';
          $title = 'Saldo Awal - ';
        }
      } else if ($page === 'mutasi') {
        $file = 'admin/mutasi.php';
        $title = 'Mutasi Kas - ';
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        if ($action === '') {
          $file = 'admin/mutasi.php';
          $title = 'Mutasi Kas - ';
        } else if ($action === 'edit') {
          $file = 'admin/edit_mutasi.php';
          $title = 'Ubah Saldo Mutasi - ';
          $script .= '<script src="assets/js/edit_fakultas.js"></script>';
        } else if ($action === 'add') {
          $file = 'admin/add_mutasi.php';
          $title = 'Tambah Data Mutasi Kas - ';
          $script = '<script src="assets/js/add_fakultas.js"></script>';
        } else {
          $file = 'admin/mutasi.php';
          $title = 'Mutasi Kas - ';
        }
      } else if ($page === 'jurnal') {
        $file = 'admin/jurnal.php';
        $title = 'Jurnal Umum - ';
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        if ($action === '') {
          $file = 'admin/jurnal.php';
          $title = 'Jurnal Umum - ';
        } else if ($action === 'edit') {
          $file = 'admin/edit_fakultas.php';
          $title = 'Ubah Data Fakultas - ';
          $script .= '<script src="assets/js/edit_fakultas.js"></script>';
        } else if ($action === 'add') {
          $file = 'admin/add_jurnal.php';
          $title = 'Tambah Data Jurnal - ';
          $script = '<script src="assets/js/add_fakultas.js"></script>';
        } else {
          $file = 'admin/jurnal.php';
          $title = 'Jurnal Umum - ';
        }
      } else if ($page === 'jurnal') {
        $file = 'admin/jurnal.php';
        $title = 'Jurnal - ';
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        $script = '<script src="assets/js/jurnal.js"></script>';
      } else if ($page === 'coa') {
        if ($action === '') {
          $file = 'admin/coa.php';
          $title = 'COA - ';
        } else if ($action === 'export') {
          $file = 'admin/export_coa_excel.php';
          $title = 'Export Excel - ';
        } else if ($action === 'add') {
          $file = 'admin/add_coa.php';
          $title = 'Tambah Data COA - ';
        } else if ($action === 'edit'){
          $file = 'admin/edit_coa.php';
          $title ='Edit Data COA - ';
        } else {
          $file = 'admin/coa.php';
          $title = 'Data COA - ';
        }
      } else if ($page === 'neraca') {
        $file = 'admin/neraca.php';
        $title = 'Program Studi - ';
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
      } else if ($page === 'LR') {
        $file = 'admin/LR.php';
        $title = 'Data Laba Rugi - ';
      } else if ($page === 'mutasi') {
        $file = 'admin/mutasi.php';
        $title = 'Data Laba Rugi - ';
      } else if ($page === 'kas') {
        $file = 'admin/kas.php';
        $title = 'Data Buku Kas - ';
        if ($action === '') {
          $file = 'admin/kas.php';
          $title = 'Data Buku Kas - ';
        } else if ($action === 'edit') {
          $file = 'admin/edit_kas.php';
          $title = 'Ubah Data Kas - ';
          $script = '<script src="assets/js/edit_fakultas.js"></script>';
        } else if ($action === 'export') {
          $file = 'admin/export_kas_ecxel.php';
          $title = 'Tambah Data Kas - ';
          $script = '<script src="assets/js/add_fakultas.js"></script>';
        } else {
          $file = 'admin/kas.php';
          $title = 'Data Buku Kas - ';
        }
      } else if ($page === 'LR') {
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        if ($action === '') {
          $file = 'admin/LR.php';
          $title = 'Data Laba Rugi - ';
        } else if ($action === 'edit') {
          $file = 'admin/edit_fakultas.php';
          $title = 'Ubah Data Fakultas - ';
          $script = '<script src="assets/js/edit_fakultas.js"></script>';
        } else if ($action === 'add') {
          $file = 'admin/add_fakultas.php';
          $title = 'Tambah Data Fakultas - ';
          $script = '<script src="assets/js/add_fakultas.js"></script>';
        } else {
          $file = 'admin/fakultas.php';
          $title = 'Data Fakultas - ';
        }
        
      } else if ($page === 'pengumuman') {
        $file = 'admin/pengumuman.php';
        $title = 'Pengumuman - ';
        $script = '<script src="vendors/sweetalert/sweetalert.min.js"></script>';
        $script = '<script src="assets/js/pengumuman.js"></script>';
      } else if ($page === 'profile') {
        $file = 'profile.php';
        $title = 'Data Pribadi - ';
        $script = '<script src="assets/js/profile.js"></script>';
      } else {
        $file = '404.php';
        $title = '404 Not Found - ';
      }
    }

    // ROUTE mahasiswa
    if ($_SESSION['role'] == 'mahasiswa') {
      if ($page === '') {
        $file = 'dashboard.php';
        $title = 'Dashboard - ';
      } else if ($page === 'pengeluaran') {
        $file = 'mahasiswa/pengeluaran.php';
        $title = 'Mata Kuliah - ';
      } else if ($page === 'khs') {
        $file = 'khs.php';
        $title = 'Laporan KHS - ';
      } else if ($page === 'profile') {
        $file = 'profile.php';
        $title = 'Data Pribadi - ';
        $script = '<script src="assets/js/profile.js"></script>';
      } else {
        $file = '404.php';
        $title = '404 Not Found - ';
      }
    }
  } else {
    if ($_SESSION['role'] == 'admin') {
      $file = 'admin/dashboard.php';
    } else {
      $file = 'dashboard.php';
    }
    $title = 'Dashboard - ';
  }
  ?>
  <title><?= $title ?>Sistem Informasi Keuangan</title>
</head>

<body>
  <div class="wrapper">
    <!-- Sidebar  -->
    <?php include('./components/sidebar.php'); ?>
    <!-- Page Content  -->
    <div id="main">
      <!-- Navbar -->
      <?php include('./components/navbar.php'); ?>
      <!-- Userinfo -->
      <div class='py-3 px-4 bg-warning text-light fs-5'>Selamat datang <?= $_SESSION['nama_lengkap'] ?> <?= $_SESSION['role'] == 'mahasiswa' ? '| Prodi: ' . $_SESSION['nama_prodi'] : '' ?> </a>
      </div>
      <!-- Content -->
      <div id="content">
        <?php
        include('./pages/' . $file);
        ?>
        <!-- End div content -->
      </div>
      <!-- End div main -->
    </div>
    <!-- End div wrapper -->
  </div>
  <!-- Script -->
  <?= $script ?>
</body>

</html>