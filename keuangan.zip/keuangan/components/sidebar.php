<nav id="sidebar">
    <div class="sidebar-header">
        <h3><span class='text-white fw-bold'>Sistem Informasi</span><br>Keuangan</h3>
    </div>
    <ul class="list-unstyled components">
        <li class="<?= !isset($page) || $page === '' ? 'active' : '' ?>">
            <a href="index.php">
                <div class="row">
                    <div class='col-12 col-md-2 sidebar-item-icon'>
                        <i class="fas fa-home"></i>
                    </div>
                    <span class="col-10">Dashboard</span>
                </div>
            </a>
        </li>
        <?php
        $menuAdmin = [
            [
                "label" => "Keuangan",
                "icon" => "fas fa-fw fa-money-bill-wave",
                "href" => "pemasukan",
            ],
        ];
        // Cek apakah halaman saat ini adalah salah satu submenu
        $submenuPages = ['pemasukan', 'pengeluaran', 'coa', 'mutasi', 'saldo', 'jurnal', 'LR', 'neraca', 'kas'];
        $isSubmenuActive = in_array($page, $submenuPages);

        if ($_SESSION['role'] == 'admin') {
            foreach ($menuAdmin as $menu) {
        ?>
                <li class="<?= $page === $menu['href'] || $isSubmenuActive ? 'active' : '' ?>">
                    <a href="javascript:void(0);" id="dataKeuanganMenuToggle">
                        <div class="row">
                            <div class='col-12 col-md-2 sidebar-item-icon'>
                                <i class="fas <?= $menu['icon'] ?>"></i>
                            </div>
                            <span class="col-10"><?= $menu['label'] ?></span>
                            <i class="ms-auto"></i>
                        </div>
                    </a>
                    <ul class="collapse list-unstyled <?= $isSubmenuActive ? 'show' : '' ?>" id="submenuDataKeuangan">
                        <li class="<?= $page === 'pemasukan' ? 'active' : '' ?>">
                            <a href="index.php?page=pemasukan">Pemasukan</a>
                        </li>
                        <li class="<?= $page === 'pengeluaran' ? 'active' : '' ?>">
                            <a href="index.php?page=pengeluaran">Pengeluaran</a>
                        </li>
                        <li class="<?= $page === 'mutasi' ? 'active' : '' ?>">
                            <a href="index.php?page=mutasi">Mutasi Kas</a>
                        </li>
                        <li class="<?= $page === 'jurnal' ? 'active' : '' ?>">
                            <a href="index.php?page=jurnal">Jurnal</a>
                        </li>
                        <li class="<?= $page === 'LR' ? 'active' : '' ?>">
                            <a href="index.php?page=LR">Laba Rugi</a>
                        </li>
                        <li class="<?= $page === 'neraca' ? 'active' : '' ?>">
                            <a href="index.php?page=neraca">Neraca</a>
                        </li>
                        <li class="<?= $page === 'kas' ? 'active' : '' ?>">
                            <a href="index.php?page=kas">Buku Kas</a>
                        <li class="<?= $page === 'coa' ? 'active' : '' ?>">
                            <a href="index.php?page=coa">COA</a>
                        </li>
                        <li class="<?= $page === 'saldo' ? 'active' : '' ?>">
                            <a href="index.php?page=saldo">Saldo Awal</a>
                        </li>
                    </ul>
                </li>
        <?php
            }
        }
        ?>
        <?php
        $menuMahasiswa = [
            [
                "label" => "Data Mata Kuliah",
                "icon" => "fa-clipboard-list",
                "href" => "matkul",
            ],
        ];
        if ($_SESSION['role'] == 'mahasiswa') {
            foreach ($menuMahasiswa as $menu) {
        ?>
                <li class="<?= $page === $menu['href'] ? 'active' : '' ?>">
                    <a href="index.php?page=<?= $menu['href'] ?>">
                        <div class="row">
                            <div class='col-12 col-md-2 sidebar-item-icon'>
                                <i class="fas <?= $menu['icon'] ?>"></i>
                            </div>
                            <span class="col-10"><?= $menu['label'] ?></span>
                        </div>
                    </a>
                </li>
        <?php
            }
        }
        ?>
    </ul>
</nav>
<!-- Tambahkan JavaScript di bagian bawah sebelum tag </body> -->
<script>
    document.getElementById('dataKeuanganMenuToggle').addEventListener('click', function() {
        var submenu = document.getElementById('submenuDataKeuangan');
        if (submenu.classList.contains('show')) {
            submenu.classList.remove('show');
        } else {
            submenu.classList.add('show');
        }
    });
</script>