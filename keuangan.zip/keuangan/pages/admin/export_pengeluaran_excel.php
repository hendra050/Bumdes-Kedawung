<?php
include('../../config/db.php');

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=data_pengeluaran.xls");

// Query untuk mengambil semua data transaksi
$query = "SELECT * FROM pengeluaran ORDER BY tgl_transaksi DESC";
$result = mysqli_query($connect, $query);

echo "<table border='1'>";
echo "<thead style='text-align:center; vertical-align: middle;'>";
echo "<tr>";
echo "<th rowspan='2'>Tanggal</th>";
echo "<th rowspan='2'>Nominal</th>";
echo "<th rowspan='2'>Uraian</th>";
echo "<th colspan='2'>Debit</th>";
echo "<th colspan='2'>Kredit</th>";
echo "</tr>";
echo "<tr style ='text-align:center'>";
echo "<td><b>ID</b></td>";
echo "<td><b>Nama Akun</b></td>";
echo "<td><b>ID</b></td>";
echo "<td><b>Nama Akun</b></td>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

while ($data = mysqli_fetch_assoc($result)) {
    $id_pengeluaran = $data['id_pengeluaran'];
    $pos_debit = $data['pos_debit'];
    $pos_kredit = $data['pos_kredit'];

    // Query untuk mendapatkan detail akun dari tabel kode_akun
    $query2 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_debit");
    $query3 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_kredit");
    $data2 = $query2->fetch_assoc();
    $data3 = $query3->fetch_assoc();

    // Gabungkan sub-akun untuk tampilan ID akun
    $debit_id = $data2['kode_akun'] . $data2['sub1_akun'] . $data2['sub2_akun'];
    $kredit_id = $data3['kode_akun'] . $data3['sub1_akun'] . $data3['sub2_akun'];
    
    echo "<tr style='text-align: center;'>";
    echo "<td>" . $data['tgl_transaksi'] . "</td>";
    echo "<td style='text-align: right;'>" . number_format($data['jumlah'], 0, ',', '.') . "</td>";
    echo "<td>" . $data['uraian'] . "</td>";
    echo "<td>" . $debit_id . "</td>";
    echo "<td>" . $data2['nama_akun'] . "</td>";
    echo "<td>" . $kredit_id . "</td>";
    echo "<td>" . $data3['nama_akun'] . "</td>";
    echo "</tr>";
}

echo "</tbody>";
echo "</table>";
?>
