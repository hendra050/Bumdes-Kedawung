<?php
$query = "SELECT id FROM users WHERE id_role = 2";
$result = $connect->query($query);
$mahasiswa = $result->num_rows;

$query = "SELECT id_pemasukan FROM pemasukan";
$result = $connect->query($query);
$pemasukan = $result->num_rows;

$query = "SELECT id_pengeluaran FROM pengeluaran";
$result = $connect->query($query);
$pengeluaran = $result->num_rows;

?>
<div class="row mt-3">
  <div class="col">
    <div class="small-box bg-success">
      <div class="inner">
        <h3> <?= $pemasukan ?> </h3>
        <p class='text-light'> Data Pemasukan </p>
      </div>
      <a href="index.php?page=pemasukan" class="icon-link">
        <i class="icon fas fa-money-bill-wave"></i>
      </a>
    </div>
  </div>
  <div class="col">
    <div class="small-box bg-info">
      <div class="inner">
        <h3> <?= $pengeluaran ?> </h3>
        <p class='text-light'> Data Pengeluaran</p>
      </div>
      <a href="index.php?page=pengeluaran" class="icon-link">
        <i class="icon fas fa-fw fa-coins"></i>
      </a>
    </div>
  </div>
</div>

<div class="row mt-3">
  <div class="col-12">
    <div class="card h-100">
      <div class="card-header">
        <h3>Pengumuman Terbaru</h3>
      </div>
      <div class="card-body">
        <?php
        $query = "SELECT * FROM berita";
        $result = $connect->query($query);
        if ($result->num_rows > 0) {
          $berita = $result->fetch_all(MYSQLI_ASSOC);
          for ($i = 0; $i < count($berita); $i++) {
        ?>

            <div class='border-bottom mb-4'>
              <h5><?= $berita[$i]['judul'] ?></h5>
              <p><?= $berita[$i]['berita'] ?></p>
            </div>

          <?php
          }
        } else {
          ?>
          <h5>Tidak ada pengumuman</h5>
        <?php
        }
        ?>
      </div>
    </div>
  </div>
</div>