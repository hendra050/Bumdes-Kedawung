<style>
    .text-right {
        text-align: right;
    }
</style>
<?php
include('./config/db.php');

$errorDelete = false;
$successStatus = false;
$successText = "";
$errorStatus = false;
$errorText = "";

// Proses penghapusan data
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_POST['id_pemasukan']) && isset($_POST['id_akun'])) {
    $id_pemasukan = $_POST['id_pemasukan'];
    $id_akun = $_POST['id_akun'];

    // Mulai transaksi
    $connect->begin_transaction();

    try {
        // Eksekusi query penghapusan dari tabel pemasukan
        $query_delete_pemasukan = "DELETE FROM pemasukan WHERE id_pemasukan = ?";
        $stmt_pemasukan = $connect->prepare($query_delete_pemasukan);
        $stmt_pemasukan->bind_param("i", $id_pemasukan);
        if (!$stmt_pemasukan->execute()) {
            throw new Exception("Gagal menghapus data dari tabel pemasukan.");
        }

        // Eksekusi query penghapusan dari tabel jurnal
        $query_delete_jurnal = "DELETE FROM jurnal WHERE id_akun = ?";
        $stmt_jurnal = $connect->prepare($query_delete_jurnal);
        $stmt_jurnal->bind_param("i", $id_akun);
        if (!$stmt_jurnal->execute()) {
            throw new Exception("Gagal menghapus data dari tabel jurnal.");
        }

        // Commit transaksi jika semua query berhasil
        $connect->commit();
        $successStatus = true;
        $successText = "Data berhasil dihapus!";
    } catch (Exception $e) {
        // Rollback transaksi jika terjadi kesalahan
        $connect->rollback();
        $errorStatus = true;
        $errorText = $e->getMessage();
    }
}

// Pagination setup
$batas = 10; // Number of items per page
$halaman = isset($_POST['halaman']) ? (int)$_POST['halaman'] : (isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1);
$halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

$previous = $halaman - 1;
$next = $halaman + 1;

// Filtering
$where = '';
$params = [];  // Array untuk parameter prepared statement
$types = '';   // Tipe data parameter

if (isset($_POST['btn-cari'])) {
    // Filter Uraian
    if (!empty($_POST['cari'])) { 
        $cari = $_POST['cari'];
        $where .= "WHERE uraian LIKE ? ";
        $params[] = "%$cari%";
        $types .= 's';
    }

    // Filter Tanggal
    $filterTanggalMulai = isset($_POST['filter_tanggal_mulai']) ? $_POST['filter_tanggal_mulai'] : '';
    $filterTanggalAkhir = isset($_POST['filter_tanggal_akhir']) ? $_POST['filter_tanggal_akhir'] : '';

    if (!empty($filterTanggalMulai) && !empty($filterTanggalAkhir)) {
        if ($where === '') {
            $where .= "WHERE tgl_transaksi BETWEEN ? AND ? ";
        } else {
            $where .= "AND tgl_transaksi BETWEEN ? AND ? ";
        }
        $params[] = $filterTanggalMulai;
        $params[] = $filterTanggalAkhir;
        $types .= 'ss';
    }
}

// Count total data
$query_count = "SELECT COUNT(*) as total FROM pemasukan $where";
$stmt_count = $connect->prepare($query_count);

// Hanya bind_param jika ada parameter
if (!empty($types)) {
    $stmt_count->bind_param($types, ...$params);
}
$stmt_count->execute();
$result_count = $stmt_count->get_result();
$data_count = $result_count->fetch_assoc();
$jumlah_data = $data_count['total'];
$total_halaman = ceil($jumlah_data / $batas);

// Fetch data for current page
$query = "SELECT * FROM pemasukan $where ORDER BY tgl_transaksi DESC LIMIT ?, ?";
$params[] = $halaman_awal;
$params[] = $batas;
$types .= 'ii';  // Untuk LIMIT dan OFFSET

$stmt = $connect->prepare($query);

// Hanya bind_param jika ada parameter
if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$data_kl = $stmt->get_result();
$nomor = $halaman_awal + 1;

$filterTanggalMulai = '';
$filterTanggalAkhir = '';
?>
<div class="row">
<input type="hidden" name="halaman" value="1">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <!-- Filtering form -->
                <form method="post">
                    <div class="row">
                        <div class="col-md-2">
                            <label for="filter_tanggal_mulai">Tanggal Awal</label>
                            <input type="date" class="form-control" name="filter_tanggal_mulai" value="<?= $filterTanggalMulai ?>">
                        </div>
                        <div class="col-md-2">
                            <label for="filter_tanggal_akhir">Tanggal Akhir</label>
                            <input type="date" class="form-control" name="filter_tanggal_akhir" value="<?= $filterTanggalAkhir ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="cari">Cari Uraian</label>
                            <input type="text" class="form-control" name="cari" placeholder="Cari Uraian">
                        </div>
                        <div class="col-md-3">
                            <br>
                            <button type="submit" name="btn-cari" class="btn btn-primary">Cari</button>
                        </div>
                        <div class="col-12 col-md-12 text-right">
                            <a href="?page=pemasukan&action=add" class="btn btn-primary" title='Tambah Pemasukan'>Tambah Pemasukan</a>
                            <a href="./pages/admin/export_pemasukan_excel.php" class="btn btn-success">Export ke Excel</a>
                        </div>
                    </div>
                </form>
                <br>
                <!-- Table displaying the data -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead style="text-align:center; vertical-align: middle;">
                            <tr>
                                <th rowspan="2">Tanggal</th>
                                <th rowspan="2">Nominal</th>
                                <th rowspan="2">Uraian</th>
                                <th colspan="2">Debit</th>
                                <th colspan="2">Kredit</th>
                                <th rowspan="2">Aksi</th>
                            </tr>
                            <tr>
                                <td><b>ID</b></td>
                                <td><b>Nama Akun</b></td>
                                <td><b>ID</b></td>
                                <td><b>Nama Akun</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($data = mysqli_fetch_assoc($data_kl)) {
                                $id_pemasukan = $data['id_pemasukan'];
                                $pos_debit = $data['pos_debit'];
                                $pos_kredit = $data['pos_kredit'];
                                $query2 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_debit");
                                $query3 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_kredit");
                                $data2 = $query2->fetch_assoc();
                                $data3 = $query3->fetch_assoc();
                            ?>
                                <tr style="text-align: center;">
                                    <td><?= date('d-m-Y', strtotime($data['tgl_transaksi'])) ?></td>
                                    <td style="text-align: right;"><?= number_format($data['jumlah'], 0, ',', '.') ?></td>
                                    <td><?= $data['uraian'] ?></td>
                                    <td><?= $data2['kode_akun'], $data2['sub1_akun'], $data2['sub2_akun'] ?></td>
                                    <td><?= $data2['nama_akun'] ?></td>
                                    <td><?= $data3['kode_akun'], $data3['sub1_akun'], $data3['sub2_akun'] ?></td>
                                    <td><?= $data3['nama_akun'] ?></td>
                                    <td>
                                        <div style="display: flex; justify-content: center; gap: 10px;">
                                            <a href="?page=pemasukan&action=edit&id=<?= $id_pemasukan ?>" class='btn btn-sm btn-primary' title='Ubah Transaksi Masuk'>
                                                <i class="fa fas fa-edit"></i>
                                            </a>
                                            <form method="post" action="?page=pemasukan&action=delete" class="formDelete" style="display: inline;">
                                                <input type="hidden" name="id_pemasukan" value="<?= $id_pemasukan ?>" />
                                                <input type="hidden" name="id_akun" value="<?= $id_akun ?>" />
                                                <button class='btn btn-sm btn-danger' title='Hapus Data Pemasukan'>
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav>
                    <ul class="pagination justify-content-center">
                        <li class="page-item">
                            <a class="page-link" <?php echo "href='?page=pemasukan&halaman=1'"; ?>>&#8249;&#8249;</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" <?php if ($halaman > 1) {
                                                        echo "href='?page=pemasukan&halaman=$previous'";
                                                    } ?>>&#8249;</a>
                        </li>
                        <?php
                        for ($x = 1; $x <= $total_halaman; $x++) {
                        ?>
                            <li class="page-item <?php if ($halaman == $x) echo 'active'; ?>">
                                <a class="page-link" href="?page=pemasukan&halaman=<?php echo $x ?>"><?php echo $x; ?></a>
                            </li>
                        <?php
                        }
                        ?>
                        <li class="page-item">
                            <a class="page-link" <?php if ($halaman < $total_halaman) {
                                                        echo "href='?page=pemasukan&halaman=$next'";
                                                    } ?>>&#8250;</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" <?php echo "href='?page=pemasukan&halaman=$total_halaman'"; ?>>&#8250;&#8250;</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if ($successStatus): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?= $successText ?>',
            showConfirmButton: true
        });
    </script>
<?php elseif ($errorStatus): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?= $errorText ?>',
            showConfirmButton: true
        });
    </script>
<?php endif; ?>