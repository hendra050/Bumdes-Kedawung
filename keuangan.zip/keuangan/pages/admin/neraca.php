<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Mulai session jika belum aktif
}
include('./config/db.php');

$categories = [
    'Aktiva' => [110, 120],
];

$sql = "
SELECT 
    k.kode_akun, 
    k.sub1_akun, 
    k.sub2_akun, 
    k.nama_akun, 
    SUM(CASE WHEN p.pos_debit IS NOT NULL THEN p.jumlah ELSE 0 END) AS total_debit,
    SUM(CASE WHEN p.pos_kredit IS NOT NULL THEN p.jumlah ELSE 0 END) AS total_kredit
FROM 
    (SELECT id_akun AS id, pos_debit, pos_kredit, jumlah FROM jurnal) AS p
JOIN 
    kode_akun AS k ON k.id = p.pos_debit OR k.id = p.pos_kredit
GROUP BY 
    k.kode_akun, k.sub1_akun, k.sub2_akun, k.nama_akun
";


$query = mysqli_query($connect, $sql);

if (!$query) {
    die('Error: ' . mysqli_error($connect));
}

$data_by_category = [
    'Aktiva' => [],
];

while ($data = mysqli_fetch_assoc($query)) {
    $kode_akun = $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'];
    $nama_akun = $data['nama_akun'];
    $total_debit = $data['total_debit'];
    $total_kredit = $data['total_kredit'];

    foreach ($categories as $category => $codes) {
        if (in_array(substr($kode_akun, 0, 3), $codes)) {
            $data_by_category[$category][] = [
                'kode_akun' => $kode_akun,
                'nama_akun' => $nama_akun,
                'total_debit' => $total_debit,
                'total_kredit' => $total_kredit
            ];
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neraca</title>
    <style>
        table {
            font-family: "Poppins", sans-serif;
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 5px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: center;
        }

        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .text-left {
            text-align: left;
        }

        .bold {
            font-weight: bold;
        }

        .total {
            font-weight: bold;
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <h2>
        <center>Neraca</center>
    </h2>

    <table>
        <thead>
            <tr>
                <th>ID Akun</th>
                <th>Nama Akun</th>
                <th>Debit</th>
                <th>Kredit</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total_all_debit = 0;
            $total_all_kredit = 0;

            foreach ($categories as $category => $codes) {
                if (!empty($data_by_category[$category])) {
                    echo "<tr><td colspan='4' class='bold'>$category</td></tr>";

                    foreach ($data_by_category[$category] as $item) {
                        echo "<tr>";
                        echo "<td class='text-center'>" . $item['kode_akun'] . "</td>";
                        echo "<td class='text-left'>" . $item['nama_akun'] . "</td>";
                        echo "<td class='text-right'>" . number_format($item['total_debit'], 0, ',', '.') . "</td>";
                        echo "<td class='text-right'>" . "</td>";
                        echo "</tr>";
                        $total_all_debit += $item['total_debit'];
                        // $total_all_kredit += $item['total_kredit'];
                    }
                }
            }
            // Ambil Laba Bersih dari session
            if (isset($_SESSION['laba_bersih'])) {
                $laba_bersih = $_SESSION['laba_bersih'];
            } else {
                $laba_bersih = 0; // Jika session belum di-set, default 0
            }
            // Tampilkan Laba Bersih di neraca
            echo "<tr class='total'>";
            echo "<td colspan='2' class='text-right'>Laba Bersih</td>";
            echo "<td class='text-right'></td>";
            echo "<td class='text-right'>" . number_format($laba_bersih, 0, ',', '.') . "</td>";
            echo "</tr>";

            $total_all_kredit += $laba_bersih;
            
            echo "<tr class='total'>";
            echo "<td colspan='2' class='text-right'>Total</td>";
            echo "<td class='text-right'>" . number_format($total_all_debit, 0, ',', '.') . "</td>";
            echo "<td class='text-right'>" . number_format($total_all_kredit, 0, ',', '.') . "</td>";
            echo "</tr>";
            ?>
        </tbody>
    </table>
</body>

</html>