<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Mulai session jika belum aktif
}
include('./config/db.php');

$categories = [
    'Pendapatan' => [410, 420],
    'Belanja' => [510, 520],
    'Biaya Usaha' => [610, 620],
];

// Query untuk mendapatkan data pendapatan, belanja, dan biaya usaha hanya dari jurnal
$sql = "
SELECT 
    k.kode_akun, 
    k.sub1_akun, 
    k.sub2_akun, 
    k.nama_akun, 
    SUM(CASE
            WHEN p.pos_debit IS NOT NULL THEN p.jumlah
            ELSE 0
        END) AS total_debit,
    SUM(CASE
            WHEN p.pos_kredit IS NOT NULL THEN p.jumlah
            ELSE 0
        END) AS total_kredit
FROM 
    (SELECT id_akun AS id, pos_debit, pos_kredit, jumlah FROM jurnal) AS p
JOIN 
    kode_akun AS k ON k.id = p.pos_debit OR k.id = p.pos_kredit
GROUP BY 
    k.kode_akun, k.sub1_akun, k.sub2_akun, k.nama_akun
";


$query = mysqli_query($connect, $sql);

// Array untuk menyimpan data yang telah dikelompokkan
$data_by_category = [
    'Pendapatan' => [],
    'Belanja' => [],
    'Biaya Usaha' => [],
];

$total_pendapatan = 0;
$total_belanja = 0;
$total_biaya_usaha = 0;

// Mengelompokkan data berdasarkan kategori
while ($data = mysqli_fetch_assoc($query)) {
    $kode_akun = $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'];
    $nama_akun = $data['nama_akun'];
    $total_debit = $data['total_debit'];
    $total_kredit = $data['total_kredit'];

    // Menentukan kategori berdasarkan kode akun
    foreach ($categories as $category => $codes) {
        if (in_array(substr($kode_akun, 0, 3), $codes)) {
            if ($category == 'Pendapatan') {
                $data_by_category['Pendapatan'][] = [
                    'kode_akun' => $kode_akun,
                    'nama_akun' => $nama_akun,
                    'total_kredit' => $total_kredit
                ];
                $total_pendapatan += $total_kredit;
            } elseif ($category == 'Belanja') {
                $data_by_category['Belanja'][] = [
                    'kode_akun' => $kode_akun,
                    'nama_akun' => $nama_akun,
                    'total_debit' => $total_debit
                ];
                $total_belanja += $total_debit;
            } elseif ($category == 'Biaya Usaha') {
                $data_by_category['Biaya Usaha'][] = [
                    'kode_akun' => $kode_akun,
                    'nama_akun' => $nama_akun,
                    'total_debit' => $total_debit
                ];
                $total_biaya_usaha += $total_debit;
            }
        }
    }
}

// Hitung Laba Bersih
$laba_bersih = $total_pendapatan - ($total_belanja + $total_biaya_usaha);

// Simpan Laba Bersih ke dalam session
$_SESSION['laba_bersih'] = $laba_bersih;

// Menampilkan tabel laporan laba rugi
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Laba Rugi</title>
    <style>
        table {
            font-family: "Poppins", sans-serif;
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 5px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: center;
        }

        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .bold {
            font-weight: bold;
        }

        .total {
            font-weight: bold;
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2><center>Laporan Laba Rugi</center></h2>
    <table>
        <thead>
            <tr>
                <th>Kode Akun</th>
                <th>Nama Akun</th>
                <th>Debit</th>
                <th>Kredit</th>
            </tr>
        </thead>
        <tbody>
            <!-- Pendapatan (Kredit) -->
            <tr><td colspan="4" class="bold">Pendapatan</td></tr>
            <?php foreach ($data_by_category['Pendapatan'] as $item): ?>
                <tr>
                    <td class="text-center"><?= $item['kode_akun'] ?></td>
                    <td><?= $item['nama_akun'] ?></td>
                    <td></td>
                    <td class="text-right"><?= number_format($item['total_kredit'], 0, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>

            <!-- Belanja (Debet) -->
            <tr><td colspan="4" class="bold">Belanja</td></tr>
            <?php foreach ($data_by_category['Belanja'] as $item): ?>
                <tr>
                    <td class="text-center"><?= $item['kode_akun'] ?></td>
                    <td><?= $item['nama_akun'] ?></td>
                    <td class="text-right"><?= number_format($item['total_debit'], 0, ',', '.') ?></td>
                    <td></td>
                </tr>
            <?php endforeach; ?>

            <!-- Biaya Usaha (Debet) -->
            <tr><td colspan="4" class="bold">Biaya Usaha</td></tr>
            <?php foreach ($data_by_category['Biaya Usaha'] as $item): ?>
                <tr>
                    <td class="text-center"><?= $item['kode_akun'] ?></td>
                    <td><?= $item['nama_akun'] ?></td>
                    <td class="text-right"><?= number_format($item['total_debit'], 0, ',', '.') ?></td>
                    <td></td>
                </tr>
            <?php endforeach; ?>

            <!-- Total -->
            <tr class="total">
                <td colspan="2">Jumlah</td>
                <td class="text-right"><?= number_format($total_belanja + $total_biaya_usaha, 0, ',', '.') ?></td>
                <td class="text-right"><?= number_format($total_pendapatan, 0, ',', '.') ?></td>
            </tr>

            <!-- Laba Bersih -->
            <tr class="total">
                <td colspan="3" class="text-right bold">Laba Bersih</td>
                <td class="text-right bold"><?= number_format($total_pendapatan - ($total_belanja + $total_biaya_usaha), 0, ',', '.') ?></td>
            </tr>
        </tbody>
    </table>
</body>
</html>