<?php
include('./config/db.php');

// Menangani pengiriman formulir
$successStatus = false;
$successText = "";
$errorStatus = false;
$errorText = "";

// Proses jika tombol 'update_jumlah' ditekan
if (isset($_POST['update_jumlah'])) {
    $id_akun = $_POST['id_akun'];
    $jumlah = str_replace('.', '', $_POST['jumlah']);
    $pos = $_POST['pos'];

    // Validasi apakah semua input sudah diisi
    if (!empty($id_akun) && !empty($jumlah) && !empty($pos)) {
        // Periksa apakah data untuk akun tersebut sudah ada di saldo
        $query_check = "SELECT COUNT(*) as count FROM saldo WHERE id = ?";
        $stmt_check = $connect->prepare($query_check);
        $stmt_check->bind_param("i", $id_akun);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $data_check = $result_check->fetch_assoc();

        if ($data_check['count'] > 0) {
            // Data ada, lakukan update
            $query_update = "UPDATE saldo SET jumlah = ?, pos = ? WHERE id = ?";
            $stmt_update = $connect->prepare($query_update);
            $stmt_update->bind_param("isi", $jumlah, $pos, $id_akun);
        } else {
            // Data tidak ada, lakukan insert
            $query_insert = "INSERT INTO saldo (id, jumlah, pos) VALUES (?, ?, ?)";
            $stmt_update = $connect->prepare($query_insert);
            $stmt_update->bind_param("iss", $id_akun, $jumlah, $pos);
        }

        // Eksekusi query dan periksa hasil
        if ($stmt_update->execute()) {
            $successStatus = true;
            $successText = "Data berhasil disimpan.";
        } else {
            $errorStatus = true;
            $errorText = "Error: " . $connect->error;
        }
    } else {
        $errorStatus = true;
        $errorText = "Semua kolom harus diisi.";
    }
}

// Proses jika tombol 'delete' ditekan
if (isset($_POST['id_akun'])) {
    $id_akun = $_POST['id_akun'];

    // Periksa apakah akun sudah digunakan dalam transaksi atau jurnal
    $query_check_jurnal = "SELECT COUNT(*) as count FROM jurnal WHERE id_akun = ?";
    $stmt_check_jurnal = $connect->prepare($query_check_jurnal);
    $stmt_check_jurnal->bind_param("i", $id_akun);
    $stmt_check_jurnal->execute();
    $result_check_jurnal = $stmt_check_jurnal->get_result();
    $data_check_jurnal = $result_check_jurnal->fetch_assoc();

    if ($data_check_jurnal['count'] > 0) {
        $errorStatus = true;
        $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
    } else {
        // Akun belum digunakan, lakukan penghapusan
        $query_delete = "DELETE FROM saldo WHERE id_akun = ?";
        $stmt_delete = $connect->prepare($query_delete);
        $stmt_delete->bind_param("i", $id_akun);

        if ($stmt_delete->execute()) {
            $successStatus = true;
            $successText = "Data berhasil dihapus.";
        } else {
            $errorStatus = true;
            $errorText = "Error: " . $connect->error;
        }
    }
}

// Pagination setup
$batas = 10; // Jumlah item per halaman
$halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
$halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

$previous = $halaman - 1;
$next = $halaman + 1;

// Hitung total data
$query_total = "SELECT COUNT(*) as total FROM saldo";
$result_total = mysqli_query($connect, $query_total);
$data_total = mysqli_fetch_assoc($result_total);
$jumlah_data = $data_total['total'];

// Hitung total halaman
$total_halaman = ceil($jumlah_data / $batas);

// Ambil data untuk halaman saat ini
$query = "SELECT id_akun, kode_akun, sub1_akun, sub2_akun, nama_akun, jumlah, pos 
          FROM saldo
          ORDER BY kode_akun
          LIMIT $halaman_awal, $batas";
$result = mysqli_query($connect, $query);

// Query untuk menjumlahkan kolom `jumlah` berdasarkan kode_akun
$query_sums = "SELECT kode_akun, SUM(jumlah) as total_jumlah
               FROM saldo
               WHERE kode_akun IN (1, 4, 5, 6)
               GROUP BY kode_akun";
$result_sums = mysqli_query($connect, $query_sums);

$totals = [];
while ($row = mysqli_fetch_assoc($result_sums)) {
    $totals[$row['kode_akun']] = number_format($row['total_jumlah'], 0, '.', '.');
}

// Akses hasil jumlah per kode akun
$total_kode_akun_1 = isset($totals[1]) ? $totals[1] : 0;
$total_kode_akun_4 = isset($totals[4]) ? $totals[4] : 0;
$total_kode_akun_5 = isset($totals[5]) ? $totals[5] : 0;
$total_kode_akun_6 = isset($totals[6]) ? $totals[6] : 0;
?>

<!-- Tambahkan referensi SweetAlert2 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if ($successStatus): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?= $successText ?>',
                confirmButtonText: 'Ok'
            });
        <?php elseif ($errorStatus): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: '<?= $errorText ?>',
                confirmButtonText: 'Ok'
            });
        <?php endif; ?>
    });
</script>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead style="text-align:center; vertical-align: middle;">
            <h2>
                <center>Saldo Awal</center>
            </h2>
            <tr>
                <th>ID Akun</th>
                <th>Nama Akun</th>
                <th>Pos</th>
                <th>Nominal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($data = mysqli_fetch_assoc($result)) {
                $id_akun = $data['id_akun'];
                $kode_akun = $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'];
                $nama_akun = $data['nama_akun'];
                $sub1_akun = $data['sub1_akun'];
                $pos = isset($data['pos']) && ($data['pos'] == 'debit' || $data['pos'] == 'kredit') ? $data['pos'] : 'debit';  // Default ke 'debit' jika tidak ada atau tidak valid

                // Logika untuk menentukan nominal berdasarkan kode_akun
                if ($kode_akun == 100) {
                    $jumlah = $total_kode_akun_1;
                } elseif ($kode_akun == 400) {
                    $jumlah = $total_kode_akun_4;
                } elseif ($kode_akun == 500) {
                    $jumlah = $total_kode_akun_5;
                } elseif ($kode_akun == 600) {
                    $jumlah = $total_kode_akun_6;
                } else {
                    $jumlah = isset($data['jumlah']) ? number_format($data['jumlah'], 0, '.', '.') : 0;
                }
            ?>
                <tr style="text-align: center;">
                    <td><?= $kode_akun ?></td>
                    <td><?= $nama_akun ?></td>
                    <td><?= ucfirst($pos) ?></td>
                    <td style="text-align:right"><?= $jumlah ?></td>
                    <td>
                        <div style="display: flex; justify-content: center; gap: 10px;">
                            <?php if ($sub1_akun != 0): ?>
                                <a href="?page=saldo&action=edit&id=<?= $id_akun ?>" class='btn btn-sm btn-primary' title='Ubah Akun'>
                                    <i class="fa fas fa-edit"></i>
                                </a>
                            <?php endif; ?>
                            <form method="post" action="?page=saldo&action=delete" class="formDelete" style="display: inline;">
                                <input type="hidden" name="id_akun" value="<?= $id_akun ?>" />
                                <button type="submit" class='btn btn-sm btn-danger' title='Hapus Akun'>
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Pagination -->
<nav>
    <ul class="pagination justify-content-center">
        <li class="page-item">
            <a class="page-link" href="?page=saldo&halaman=1">&#8249;&#8249;</a>
        </li>
        <li class="page-item">
            <a class="page-link" <?php if ($halaman > 1) echo "href='?page=saldo&halaman=$previous'"; ?>>
                <</a>
        </li>
        <?php
        for ($x = 1; $x <= $total_halaman; $x++) {
            $active = ($x == $halaman) ? "active" : "";
            echo "<li class='page-item $active'><a class='page-link' href='?page=saldo&halaman=$x'>$x</a></li>";
        }
        ?>
        <li class="page-item">
            <a class="page-link" <?php if ($halaman < $total_halaman) echo "href='?page=saldo&halaman=$next'"; ?>>></a>
        </li>
        <li class="page-item">
            <a class="page-link" href="?page=saldo&halaman=<?= $total_halaman ?>">&#8250;&#8250;</a>
        </li>
    </ul>
</nav>