<style>
    table {
        font-family: "Poppins", sans-serif;
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        padding: 5px;
        text-align: left;
        border: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
        font-weight: bold;
        text-align: center;
    }

    tbody tr:nth-child(even) {
        background-color: #f2f2f2;
        /* Warna abu-abu muda */
    }

    tbody tr:nth-child(odd) {
        background-color: #ffffff;
        /* Warna putih */
    }

    .text-left {
        text-align: left;
    }

    .text-right {
        text-align: right;
    }
</style>

<?php
include('./config/db.php');

// Proses hapus data
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Mulai transaksi
    $connect->begin_transaction();

    try {
        // Query untuk menghapus data dari tabel jurnal
        $deleteJurnalQuery = "DELETE FROM jurnal WHERE id_akun = ?";
        $stmt1 = $connect->prepare($deleteJurnalQuery);
        $stmt1->bind_param('i', $id);
        $stmt1->execute();

        // Query untuk menghapus data dari tabel pemasukan (jika ada data di sini)
        $deletePemasukanQuery = "DELETE FROM pemasukan WHERE id_pemasukan = ?";
        $stmt2 = $connect->prepare($deletePemasukanQuery);
        $stmt2->bind_param('i', $id);
        $stmt2->execute();

        // Query untuk menghapus data dari tabel pengeluaran (jika ada data di sini)
        $deletePengeluaranQuery = "DELETE FROM pengeluaran WHERE id_pengeluaran = ?";
        $stmt3 = $connect->prepare($deletePengeluaranQuery);
        $stmt3->bind_param('i', $id);
        $stmt3->execute();

        // Commit transaksi jika semua berhasil
        $connect->commit();

        echo "<script>
                Swal.fire({
                    title: 'Terhapus!',
                    text: 'Data berhasil dihapus dari semua tabel.',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '?page=jurnal';
                    }
                });
              </script>";
    } catch (Exception $e) {
        // Rollback transaksi jika terjadi kesalahan
        $connect->rollback();

        echo "<script>
                Swal.fire({
                    title: 'Gagal!',
                    text: 'Data gagal dihapus: " . $e->getMessage() . "',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
              </script>";
    }
}
?>

<?php
$filterTanggalMulai = isset($_POST['filter_tanggal_mulai']) ? $_POST['filter_tanggal_mulai'] : (isset($_GET['filter_tanggal_mulai']) ? $_GET['filter_tanggal_mulai'] : '');
$filterTanggalAkhir = isset($_POST['filter_tanggal_akhir']) ? $_POST['filter_tanggal_akhir'] : (isset($_GET['filter_tanggal_akhir']) ? $_GET['filter_tanggal_akhir'] : '');

$where = '';

// Filter tanggal
if (!empty($filterTanggalMulai) && !empty($filterTanggalAkhir)) {
    $where = "WHERE tgl_transaksi BETWEEN '$filterTanggalMulai' AND '$filterTanggalAkhir'";
}

// Query tanpa batasan halaman (pagination)
$query = "
    SELECT 'jurnal' as type, id_akun as id, tgl_transaksi, uraian, pos_debit, pos_kredit, jumlah 
    FROM jurnal
    $where
    ORDER BY tgl_transaksi ASC";
$stmt = $connect->prepare($query);
$stmt->execute();
$data_kl = $stmt->get_result();
$no = 1;
$total_debit = 0; // Initialize total debit
$total_kredit = 0; // Initialize total kredit
?>

<h2>
    <center> Tabel Jurnal Umum</center>
</h2>
<form method="post" id="filterForm">
    <div class="row">
        <div class="col-md-2">
            <label for="filter_tanggal_mulai">Tanggal Awal</label>
            <input type="date" id="filter_tanggal_mulai" class="form-control" name="filter_tanggal_mulai" value="<?= isset($_POST['filter_tanggal_mulai']) ? $_POST['filter_tanggal_mulai'] : ''; ?>">
        </div>
        <div class="col-md-2">
            <label for="filter_tanggal_akhir">Tanggal Akhir</label>
            <input type="date" id="filter_tanggal_akhir" class="form-control" name="filter_tanggal_akhir" value="<?= isset($_POST['filter_tanggal_akhir']) ? $_POST['filter_tanggal_akhir'] : ''; ?>">
        </div>
        <div class="col-md-3">
            <br>
            <button type="submit" name="btn-cari" class="btn btn-primary">Cari</button>
        </div>
    </div>
</form>
<script>
    document.getElementById('filterForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Mencegah submit default

        // Simpan nilai-nilai filter sebelum submit
        let tanggalMulai = document.getElementById('filter_tanggal_mulai').value;
        let tanggalAkhir = document.getElementById('filter_tanggal_akhir').value;

        // Lakukan proses submit manual dengan nilai form
        let formData = new FormData(this);

        // Melakukan fetch post untuk pengiriman data
        fetch('', {
                method: 'POST',
                body: formData
            }).then(response => response.text())
            .then(html => {
                // Menggantikan konten body dengan data hasil pencarian
                document.body.innerHTML = html;

                // Reset field tanggal setelah hasil muncul
                document.getElementById('filter_tanggal_mulai').value = '';
                document.getElementById('filter_tanggal_akhir').value = '';
            }).catch(error => {
                console.error('Error:', error);
            });
    });
</script>

<div class="col-12 col-md-12 text-right">
    <a href="?page=jurnal&action=add" class="btn btn-primary" title='Tambah Jurnal'>Tambah Jurnal</a>
    <a href="./pages/admin/export_jurnal_excel.php" class="btn btn-success">Export ke Excel</a>
</div><br>
<table>
    <thead>
        <tr>
            <th>NO</th>
            <th>TANGGAL</th>
            <th>URAIAN</th>
            <th>AKUN DEBIT</th>
            <th>AKUN KREDIT</th>
            <th>DEBET</th>
            <th>KREDIT</th>
            <th>AKSI</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($data = mysqli_fetch_assoc($data_kl)) {
            $pos_debit = $data['pos_debit'];
            $pos_kredit = $data['pos_kredit'];
            $query2 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_debit");
            $query3 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_kredit");

            $data2 = $query2->fetch_assoc();
            $data3 = $query3->fetch_assoc();

            $total_debit += $data['jumlah'];
            $total_kredit += $data['jumlah'];
        ?>
            <tr id="row-<?= $data['id'] ?>">
                <td style="text-align: center;"><?= $no++; ?></td>
                <td style="text-align: center;"><?= date('d-m-Y', strtotime($data['tgl_transaksi'])) ?></td>
                <td class="text-left"><?= $data['uraian'] ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <button type="button" onclick="deleteEntry(<?= $data['id'] ?>)" class='btn btn-sm btn-danger' title='Hapus Data jurnal'>
                        <i class="fa fa-trash"></i>
                    </button>
                </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="text-left"><?= $data2['nama_akun'] ?></td>
                <td style="text-align: center;"><?= $data2['kode_akun'], $data2['sub1_akun'], $data2['sub2_akun'] ?></td>
                <td></td>
                <td style="text-align: right;"><?= number_format($data['jumlah'], 0, '.', '.'); ?></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="text-left"><?= $data3['nama_akun'] ?></td>
                <td></td>
                <td style="text-align: center;"><?= $data3['kode_akun'], $data3['sub1_akun'], $data3['sub2_akun'] ?></td>
                <td></td>
                <td style="text-align: right;"><?= number_format($data['jumlah'], 0, '.', '.'); ?></td>
                <td></td>
            </tr>
        <?php } ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="5" class="text-right"><strong>TOTAL:</strong></td>
            <td class="text-right"><strong><?= number_format($total_debit, 0, '.', '.') ?></strong></td>
            <td class="text-right"><strong><?= number_format($total_kredit, 0, '.', '.') ?></strong></td>
            <td></td>
        </tr>
    </tfoot>
</table>

<script>
    function deleteEntry(id) {
        Swal.fire({
            title: 'Yakin menghapus?',
            text: "Data akan terhapus secara permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '?page=jurnal&action=delete&id=' + id;
            }
        });
    }
</script>
