<?php
include('../../config/db.php');

// Set header agar browser mengerti bahwa ini adalah file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=buku_kas.xls");

// Filter Tanggal
$filterTanggalMulai = isset($_POST['filter_tanggal_mulai']) ? $_POST['filter_tanggal_mulai'] : '';
$filterTanggalAkhir = isset($_POST['filter_tanggal_akhir']) ? $_POST['filter_tanggal_akhir'] : '';

$where = '';

if (!empty($filterTanggalMulai) && !empty($filterTanggalAkhir)) {
    $where = "WHERE tgl_transaksi BETWEEN '$filterTanggalMulai' AND '$filterTanggalAkhir'";
} 

// Query untuk mengambil data kas
$sql = "
SELECT 'pemasukan' as type, id_pemasukan as id, tgl_transaksi, uraian, pos_debit, pos_kredit, jumlah 
FROM pemasukan
$where
UNION ALL
SELECT 'pengeluaran' as type, id_pengeluaran as id, tgl_transaksi, uraian, pos_debit, pos_kredit, jumlah
FROM pengeluaran
$where
UNION ALL
SELECT 'jurnal' as type, id_jurnal as id, tgl_transaksi, uraian, pos_debit, pos_kredit, jumlah
FROM jurnal
$where
ORDER BY tgl_transaksi ASC
";

$result = mysqli_query($connect, $sql);

if (!$result) {
    die("Error: " . mysqli_error($connect));
}

// Membuat tabel untuk Excel
echo "<table border='1'>";
echo "<tr>";
echo "<th>No</th>";
echo "<th>Tanggal</th>";
echo "<th>Uraian</th>";
echo "<th>Masuk</th>";
echo "<th>Keluar</th>";
echo "<th>Saldo</th>";
echo "</tr>";

$no = 1;
$saldo = 0;

// Mengambil data dari database
while ($data = mysqli_fetch_assoc($result)) {
    $pos_debit = $data['pos_debit'];
    $pos_kredit = $data['pos_kredit'];

    // Format tanggal untuk hanya menampilkan tanggal tanpa waktu
    $dateTime = new DateTime($data['tgl_transaksi']);
    $formattedDate = $dateTime->format('d-m-Y');

    if ($data['type'] == 'pemasukan') {
        $masuk = $data['jumlah'];
        $keluar = 0;
    } else if ($data['type'] == 'pengeluaran') {
        $masuk = 0;
        $keluar = $data['jumlah'];
    } else if ($data['type'] == 'jurnal') {
        $masuk = 0;
        $keluar = $data['jumlah'];
    } else {
        $masuk = 0;
        $keluar = 0; // Menambahkan kondisi default untuk keamanan
    }

    $saldo += $masuk - $keluar;

    echo "<tr>";
    echo "<td style='text-align: center;'>{$no}</td>";
    echo "<td style='text-align: center;'>{$formattedDate}</td>"; // Menggunakan tanggal yang sudah diformat
    echo "<td>{$data['uraian']}</td>";
    echo "<td style='text-align: right;'>" . ($masuk != 0 ? number_format($masuk, 0, ',', '.') : '') . "</td>";
    echo "<td style='text-align: right;'>" . ($keluar != 0 ? number_format($keluar, 0, ',', '.') : '') . "</td>";
    echo "<td style='text-align: right;'>" . number_format($saldo, 0, ',', '.') . "</td>";
    echo "</tr>";

    $no++;
}


echo "</table>";
?>
