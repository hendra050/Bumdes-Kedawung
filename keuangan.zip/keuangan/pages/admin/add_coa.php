<?php
include('./config/db.php'); // Include database connection file

$error = false;
$success = false;  // Success flag

if (isset($_POST['simpan'])) {
    // Ambil data dari form
    $id_akun = isset($_POST['id_akun']) ? trim($_POST['id_akun']) : '';
    $nama_akun = isset($_POST['nama_akun']) ? trim($_POST['nama_akun']) : '';
    $pencapaian = isset($_POST['pencapaian']) ? trim($_POST['pencapaian']) : '';

    // Validasi
    if (empty($id_akun) || empty($nama_akun)) {
        $error = true;
        $errorText = "Semua field harus diisi.";
    } else {
        // Pisahkan id_akun menjadi kode_akun, sub1_akun, dan sub2_akun
        $kode_akun = substr($id_akun, 0, 1);
        $sub1_akun = substr($id_akun, 1, 1);
        $sub2_akun = substr($id_akun, 2, 1);

        // Cek apakah id_akun sudah ada di tabel kode_akun
        $check_sql = "SELECT id_akun FROM coa WHERE kode_akun = '$kode_akun' AND sub1_akun = '$sub1_akun' AND sub2_akun = '$sub2_akun'";
        $result = $connect->query($check_sql);

        if ($result->num_rows > 0) {
            $error = true;
            $errorText = "ID Akun sudah ada, silakan gunakan kombinasi yang berbeda.";
        } else {
            // Masukkan data ke tabel kode_akun
            $sql = "INSERT INTO coa (kode_akun, sub1_akun, sub2_akun, nama_akun, pencapaian) VALUES ( '$kode_akun', '$sub1_akun', '$sub2_akun', '$nama_akun', '$pencapaian')";

            if ($connect->query($sql) === TRUE) {
                $success = true;  // Set success flag to true
            } else {
                $error = true;
                $errorText = "Error: " . $connect->error;
            }
        }
    }
}
?>

<div class="row">
  <div class="col-12 col-md-6">
    <a class="btn btn-success" href="?page=coa"><i class="fa fa-arrow-left"></i> Kembali</a>
  </div>
</div><br>

<form method="POST" enctype="multipart/form-data">
  <div class="row">
    <div class="col-lg-12 mb-9">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Akun</h6>
      </div>

      <div class="modal-body">
        <div class="form-group">
          <label>ID Akun :</label>
          <input type="text" class="form-control" name="id_akun" required style="max-width: 250px;">
        </div>
        <div class="form-group">
          <label>Nama Akun :</label>
          <input type="text" class="form-control" name="nama_akun" required style="max-width: 250px;">
        </div>
        <div class="form-group">
          <label>Target :</label>
          <input type="text" class="form-control" name="pencapaian" required style="max-width: 250px;">
        </div>
      </div>
      <div class="form-group">
        <button type="submit" name="simpan" class="btn btn-primary" style="background-color: darkcyan;">Simpan</button>
      </div>
    </div>
  </div>
</form>

<!-- SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
// Check for success from PHP
<?php if ($success): ?>
    Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: 'Data berhasil ditambahkan.',
        showConfirmButton: false,
        timer: 1500
    }).then(function() {
        window.location = 'index.php?page=coa'; // Redirect after SweetAlert is closed
    });
<?php elseif ($error): ?>
    Swal.fire({
        icon: 'error',
        title: 'Gagal!',
        text: '<?php echo $errorText; ?>'
    });
<?php endif; ?>
</script>