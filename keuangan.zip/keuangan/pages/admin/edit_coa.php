<?php
include('./config/db.php'); // Masukkan file koneksi database

$error = false;
$success = false; // Variabel untuk menyimpan status keberhasilan
$errorText = "";

// Ambil ID data dari parameter URL, misal: edit.php?id=1
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Jika ID tidak ada, redirect ke halaman utama atau tampilkan pesan error
if ($id === null) {
    die("ID tidak ditemukan.");
}

// Ambil data dari database berdasarkan ID
$sql = "SELECT * FROM coa WHERE id_akun = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    die("Data tidak ditemukan.");
}

// Jika formulir disubmit
if (isset($_POST['simpan'])) {
    // Ambil data dari input form
    $id_akun = $_POST['id_akun'];  // Gabungan kode_akun, sub1_akun, sub2_akun
    $nama_akun = $_POST['nama_akun'];
    $pencapaian = str_replace('.', '', $_POST['pencapaian']);

    // Pisahkan id_akun menjadi kode_akun, sub1_akun, sub2_akun
    $kode_akun = substr($id_akun, 0, 1);  // Misalnya 3 digit pertama untuk kode_akun
    $sub1_akun = substr($id_akun, 1, 1);  // Misalnya 2 digit berikutnya untuk sub1_akun
    $sub2_akun = substr($id_akun, 2, 1);  // Misalnya 2 digit terakhir untuk sub2_akun

    // Validasi sederhana
    if (empty($id_akun) || empty($nama_akun)) {
        $error = true;
        $errorText = "Semua kolom harus diisi.";
    } else {
        // Update data ke database
        $sql_update = "UPDATE coa SET kode_akun = ?, sub1_akun = ?, sub2_akun = ?, nama_akun = ?, pencapaian = ? WHERE id_akun = ?";
        $stmt_update = $connect->prepare($sql_update);
        $stmt_update->bind_param("sssssi", $kode_akun, $sub1_akun, $sub2_akun, $nama_akun, $pencapaian, $id);

        if ($stmt_update->execute()) {
            $success = true; // Set flag success ke true
        } else {
            $error = true;
            $errorText = "Error: " . $stmt_update->error;
        }
    }
}
?>

<div class="row">
    <div class="col-12 col-md-6">
        <a class="btn btn-success" href="?page=coa"><i class="fa fa-arrow-left"></i> Kembali</a>
    </div>
</div><br>

<form method="POST" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-12 mb-9">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Akun COA</h6>
            </div>

            <div class="modal-body">
                <!-- Input ID Akun -->
                <label>ID Akun :</label>
                <input type="text" class="form-control" id="id_akun" name="id_akun"
                    value="<?php echo isset($data['kode_akun']) && isset($data['sub1_akun']) && isset($data['sub2_akun']) ? $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'] : ''; ?>"
                    required style="max-width: 200px;" readonly>

                <!-- Nama Akun -->
                <label>Nama Akun :</label>
                <input type="text" class="form-control" name="nama_akun"
                    value="<?php echo isset($data['nama_akun']) ? $data['nama_akun'] : ''; ?>"
                    required style="max-width: 250px;" readonly>

                <!-- Target -->
                <label>Target :</label>
                <input type="text" class="form-control" id="pencapaian" name="pencapaian"
                    value="<?php echo isset($data['pencapaian']) ? number_format($data['pencapaian'], 0, '.', '.') : ''; ?>"
                    required style="max-width: 250px;">
            </div>

            <div class="form-group">
                <button type="submit" name="simpan" class="btn btn-primary" style="background-color: darkcyan;">Simpan</button>
            </div>
        </div>
    </div>
</form>



<!-- Tambahkan SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Cek apakah ada sukses dari PHP
    <?php if ($success): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: 'Data berhasil diedit.',
            showConfirmButton: false,
            timer: 1500
        }).then(function() {
            window.location = '?page=coa'; // Redirect setelah SweetAlert ditutup
        });
    <?php elseif ($error): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?php echo $errorText; ?>'
        });
    <?php endif; ?>
</script>

<script>
    document.getElementById('pencapaian').addEventListener('input', function(e) {
        let value = e.target.value;

        // Remove existing thousand separators (dots)
        value = value.replace(/\./g, '');

        // Remove non-numeric characters
        value = value.replace(/[^0-9]/g, '');

        // Add thousand separators (dot)
        if (value !== '') {
            value = parseInt(value, 10).toLocaleString('id-ID');
        }

        // Update the input field with the new formatted value
        e.target.value = value;
    });
</script>