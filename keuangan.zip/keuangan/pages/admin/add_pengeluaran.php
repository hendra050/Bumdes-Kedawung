<?php
include('./config/db.php'); // Masukkan file koneksi database

// Query untuk mendapatkan kode akun dan sub1_akun, dengan syarat sub1_akun tidak bernilai 0
$query_pos_kredit = "SELECT id, sub1_akun, nama_akun FROM kode_akun WHERE kode_akun = 1 ORDER BY kode_akun ASC";
$result_pos_kredit = $connect->query($query_pos_kredit);

$query_pos_debit = "SELECT id, sub1_akun, nama_akun FROM kode_akun WHERE kode_akun in (5,6) ORDER BY kode_akun ASC";
$result_pos_debit = $connect->query($query_pos_debit);

$error = false;
$errorText = "";
$success = false; // Inisialisasi variabel sukses

if (isset($_POST['simpan'])) {
  $tgl_transaksi = $_POST['tgl_transaksi'];
  $jumlah = preg_replace('/\D/', '', $_POST['jumlah']);
  $uraian = $_POST['uraian'];
  $pos_debit = $_POST['pos_debit'];
  $pos_kredit = $_POST['pos_kredit'];

  // Validasi sederhana
  if (empty($tgl_transaksi) || empty($jumlah) || empty($uraian) || empty($pos_debit) || empty($pos_kredit)) {
    $error = true;
    $errorText = "Semua kolom harus diisi.";
  } else {
    // Memulai transaksi
    $connect->begin_transaction();

    try {
      // Query untuk tabel pengeluaran
      $sql1 = "INSERT INTO pengeluaran (tgl_transaksi, jumlah, uraian, pos_debit, pos_kredit) 
               VALUES ('$tgl_transaksi', '$jumlah', '$uraian', '$pos_debit', '$pos_kredit')";

      if ($connect->query($sql1) !== TRUE) {
        throw new Exception("Error in pengeluaran query: " . $connect->error);
      }

      // Query untuk tabel jurnal
      $sql2 = "INSERT INTO jurnal (tgl_transaksi, jumlah, uraian, pos_debit, pos_kredit) 
               VALUES ('$tgl_transaksi', '$jumlah', '$uraian', '$pos_debit', '$pos_kredit')";

      if ($connect->query($sql2) !== TRUE) {
        throw new Exception("Error in jurnal query: " . $connect->error);
      }

      // Commit transaksi jika kedua query berhasil
      $connect->commit();
      $success = true;
    } catch (Exception $e) {
      // Rollback transaksi jika ada error
      $connect->rollback();
      $error = true;
      $errorText = $e->getMessage();
    }
  }
}
// Menghitung total pemasukan untuk Kas Besar
$pemasukan_kas_besar_query = "
  SELECT SUM(jumlah) as total_pemasukan 
  FROM jurnal 
  WHERE pos_debit = 2"; // 2 adalah kode untuk Kas Besar
$pemasukan_kas_besar_result = mysqli_query($connect, $pemasukan_kas_besar_query);
if (!$pemasukan_kas_besar_result) {
  die('Error: ' . mysqli_error($connect));
}
$pemasukan_kas_besar_row = mysqli_fetch_assoc($pemasukan_kas_besar_result);
$total_pemasukan_kas_besar = $pemasukan_kas_besar_row['total_pemasukan'] ?? 0;

// Menghitung total pengeluaran untuk Kas Besar
$pengeluaran_kas_besar_query = "
  SELECT SUM(jumlah) as total_pengeluaran 
  FROM jurnal 
  WHERE pos_kredit = 2"; // 2 adalah kode untuk Kas Besar
$pengeluaran_kas_besar_result = mysqli_query($connect, $pengeluaran_kas_besar_query);
if (!$pengeluaran_kas_besar_result) {
  die('Error: ' . mysqli_error($connect));
}
$pengeluaran_kas_besar_row = mysqli_fetch_assoc($pengeluaran_kas_besar_result);
$total_pengeluaran_kas_besar = $pengeluaran_kas_besar_row['total_pengeluaran'] ?? 0;

// Menghitung saldo Kas Besar
$total_saldo_kas_besar = $total_pemasukan_kas_besar - $total_pengeluaran_kas_besar;

// Menghitung total pemasukan untuk Kas Kecil
$pemasukan_kas_kecil_query = "
  SELECT SUM(jumlah) as total_pemasukan 
  FROM jurnal 
  WHERE pos_debit = 3"; // 3 adalah kode untuk Kas Kecil
$pemasukan_kas_kecil_result = mysqli_query($connect, $pemasukan_kas_kecil_query);
if (!$pemasukan_kas_kecil_result) {
  die('Error: ' . mysqli_error($connect));
}
$pemasukan_kas_kecil_row = mysqli_fetch_assoc($pemasukan_kas_kecil_result);
$total_pemasukan_kas_kecil = $pemasukan_kas_kecil_row['total_pemasukan'] ?? 0;

// Menghitung total pengeluaran untuk Kas Kecil
$pengeluaran_kas_kecil_query = "
  SELECT SUM(jumlah) as total_pengeluaran 
  FROM jurnal 
  WHERE pos_kredit = 3"; // 3 adalah kode untuk Kas Kecil
$pengeluaran_kas_kecil_result = mysqli_query($connect, $pengeluaran_kas_kecil_query);
if (!$pengeluaran_kas_kecil_result) {
  die('Error: ' . mysqli_error($connect));
}
$pengeluaran_kas_kecil_row = mysqli_fetch_assoc($pengeluaran_kas_kecil_result);
$total_pengeluaran_kas_kecil = $pengeluaran_kas_kecil_row['total_pengeluaran'] ?? 0;

// Menghitung saldo Kas Kecil
$total_saldo_kas_kecil = $total_pemasukan_kas_kecil - $total_pengeluaran_kas_kecil;

?>

<div class="row">
  <div class="col-12 col-md-6">
    <a class="btn btn-success" href="?page=pengeluaran"><i class="fa fa-arrow-left"></i> Kembali</a>
  </div>
</div><br>

<form method="POST" enctype="multipart/form-data">
  <div class="row">
    <div class="col-lg-12 mb-9">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Transaksi Keluar</h6>
      </div>

      <div class="modal-body">
        <div class="form-group">
          <label>Tanggal Transaksi :</label>
          <input type="date" class="form-control" name="tgl_transaksi" required style="max-width: 200px;">
        </div>
        <div class="form-group">
          <label>Nilai Transaksi :</label>
          <input type="text" class="form-control" name="jumlah" id="jumlah" required style="max-width: 200px;">
        </div>
        <div class="form-group">
          <label>Uraian :</label>
          <textarea name="uraian" id="uraian" class="form-control" required></textarea>
        </div>
        <div class="form-group">
          <label>Pos Debit :</label>
          <select class="form-control" name="pos_debit" required style="max-width: 350px">
            <option value=""></option>
            <?php while ($row = $result_pos_debit->fetch_assoc()): ?>
              <?php if ($row['sub1_akun'] != 0): ?>
                <option value="<?= $row['id']; ?>"> <!-- value adalah id -->
                  <?= $row['nama_akun']; ?> <!-- yang ditampilkan adalah nama_akun -->
                </option>
              <?php endif; ?>
            <?php endwhile; ?>
          </select>
          <form method="POST" enctype="multipart/form-data">
            <!-- Form fields here -->
            <div class="form-group">
              <label>Pos Kredit :</label>
              <select id="pos_kredit" class="form-control" name="pos_kredit" required style="max-width: 350px">
                <option value=""></option>
                <?php while ($row = $result_pos_kredit->fetch_assoc()): ?>
                  <?php if ($row['sub1_akun'] != 0): ?>
                    <option value="<?= $row['id']; ?>">
                      <?= $row['nama_akun']; ?>
                    </option>
                  <?php endif; ?>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Saldo :</label>
              <input type="text" id="saldo" class="form-control" readonly style="max-width: 350px">
            </div>
            <!-- Rest of the form -->
          </form>
        </div>
      </div>
      <div class="form-group">
        <button type="submit" name="simpan" href="?page=pengeluaran" class="btn btn-primary" style="background-color: darkcyan;">Simpan</button>
      </div>
    </div>
  </div>
</form>

<!-- Tambahkan SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  // Cek apakah ada sukses dari PHP
  <?php if ($success): ?>
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Data berhasil ditambahkan.',
      showConfirmButton: false,
      timer: 1500
    }).then(function() {
      window.location = '?page=pengeluaran'; // Redirect setelah SweetAlert ditutup
    });
  <?php elseif ($error): ?>
    Swal.fire({
      icon: 'error',
      title: 'Gagal!',
      text: '<?php echo $errorText; ?>'
    });
  <?php endif; ?>
</script>

<script>
  // Format angka dengan titik ribuan pada input jumlah
  document.getElementById('jumlah').addEventListener('input', function(e) {
    var value = e.target.value;
    value = value.replace(/[^0-9]/g, '');
    value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    e.target.value = value;
  });
</script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var posKreditSelect = document.getElementById('pos_kredit');
    var saldoInput = document.getElementById('saldo');

    // Buat variabel untuk saldo kas besar dan kas kecil dari PHP
    var saldoKasBesar = <?= json_encode(number_format($total_saldo_kas_besar, 0, ',', '.')) ?>;
    var saldoKasKecil = <?= json_encode(number_format($total_saldo_kas_kecil, 0, ',', '.')) ?>;

    // Fungsi untuk mengupdate saldo berdasarkan pilihan pos kredit
    function updateSaldo() {
      var selectedPosKredit = posKreditSelect.value;

      // Jika memilih kas besar, tampilkan saldo kas besar
      if (selectedPosKredit == '2') {
        saldoInput.value = saldoKasBesar;
      }
      // Jika memilih kas kecil, tampilkan saldo kas kecil
      else if (selectedPosKredit == '3') {
        saldoInput.value = saldoKasKecil;
      }
      // Jika tidak memilih pos kredit, tampilkan total saldo kas besar dan kas kecil
      else {
        var totalSaldo = parseFloat(saldoKasBesar.replace(/\./g, '').replace(',', '.')) +
          parseFloat(saldoKasKecil.replace(/\./g, '').replace(',', '.'));
        saldoInput.value = totalSaldo.toLocaleString('id-ID', {
          minimumFractionDigits: 0
        });
      }
    }

    // Panggil fungsi updateSaldo saat dropdown berubah
    posKreditSelect.addEventListener('change', updateSaldo);

    // Panggil sekali saat halaman dimuat untuk menetapkan nilai default
    updateSaldo();
  });
</script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var posKreditSelect = document.getElementById('pos_kredit');
    var saldoInput = document.getElementById('saldo');
    var jumlahInput = document.getElementById('jumlah');
    var form = document.querySelector('form');

    // Buat variabel untuk saldo kas besar dan kas kecil dari PHP
    var saldoKasBesar = <?= json_encode($total_saldo_kas_besar) ?>;
    var saldoKasKecil = <?= json_encode($total_saldo_kas_kecil) ?>;

    // Fungsi untuk mengupdate saldo berdasarkan pilihan pos kredit
    function updateSaldo() {
      var selectedPosKredit = posKreditSelect.value;

      // Jika memilih kas besar, tampilkan saldo kas besar
      if (selectedPosKredit == '2') {
        saldoInput.value = saldoKasBesar.toLocaleString('id-ID');
      }
      // Jika memilih kas kecil, tampilkan saldo kas kecil
      else if (selectedPosKredit == '3') {
        saldoInput.value = saldoKasKecil.toLocaleString('id-ID');
      }
    }

    // Validasi sebelum submit
    form.addEventListener('submit', function(e) {
      var selectedPosKredit = posKreditSelect.value;
      var saldoTersedia = selectedPosKredit == '2' ? saldoKasBesar : saldoKasKecil;
      var jumlahTransaksi = parseFloat(jumlahInput.value.replace(/\./g, '').replace(',', '.')) || 0;

      if (jumlahTransaksi > saldoTersedia) {
        // Tampilkan peringatan jika saldo kurang
        e.preventDefault(); // Batalkan pengiriman form
        Swal.fire({
          icon: 'warning',
          title: 'Saldo Tidak Cukup!',
          text: 'Saldo tidak mencukupi untuk melakukan transaksi ini.'
        });
      }
    });

    // Panggil fungsi updateSaldo saat dropdown berubah
    posKreditSelect.addEventListener('change', updateSaldo);

    // Panggil sekali saat halaman dimuat untuk menetapkan nilai default
    updateSaldo();
  });
</script>