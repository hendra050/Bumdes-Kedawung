<?php
include('../../config/db.php');

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=data_coa.xls");

// Query untuk mengambil semua data COA
$query = "SELECT id, kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun ORDER BY id";
$result = mysqli_query($connect, $query);

echo "<table border='1'>";
echo "<tr>";
echo "<th>ID Akun</th>";
echo "<th>Kode Akun</th>";
echo "<th>Nama Akun</th>";
echo "</tr>";

while ($data = mysqli_fetch_assoc($result)) {
    $id_akun = $data['id'];
    $kode_akun = $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'];
    $nama_akun = $data['nama_akun'];
    
    echo "<tr>";
    echo "<td>$id_akun</td>";
    echo "<td>$kode_akun</td>";
    echo "<td>$nama_akun</td>";
    echo "</tr>";
}

echo "</table>";
?>