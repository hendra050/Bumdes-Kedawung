<?php
include('./config/db.php'); // Masukkan file koneksi database

// Query untuk mendapatkan kode akun dan sub1_akun, dengan syarat sub1_akun tidak bernilai 0
$query_pos_kredit = "SELECT id, sub1_akun, nama_akun FROM kode_akun WHERE kode_akun = 4 ORDER BY kode_akun ASC";
$result_pos_kredit = $connect->query($query_pos_kredit);

$query_pos_debit = "SELECT id, sub1_akun, nama_akun FROM kode_akun WHERE kode_akun = 1 ORDER BY kode_akun ASC";
$result_pos_debit = $connect->query($query_pos_debit);

$error = false;
$success = false;  // Flag untuk sukses

if (isset($_POST['simpan'])) {
  $tgl_transaksi = $_POST['tgl_transaksi'];
  $jumlah = preg_replace('/\D/', '', $_POST['jumlah']);
  $uraian = $_POST['uraian'];
  $pos_debit = $_POST['pos_debit'];
  $pos_kredit = $_POST['pos_kredit'];

  // Validasi sederhana
  if (empty($tgl_transaksi) || empty($jumlah) || empty($uraian) || empty($pos_debit) || empty($pos_kredit)) {
    $error = true;
    $errorText = "Semua kolom harus diisi.";
  } else {
    // Memulai transaksi
    $connect->begin_transaction();

    try {
      // Query untuk tabel pengeluaran
      $sql1 = "INSERT INTO pemasukan (tgl_transaksi, jumlah, uraian, pos_debit, pos_kredit) 
               VALUES ('$tgl_transaksi', '$jumlah', '$uraian', '$pos_debit', '$pos_kredit')";

      if ($connect->query($sql1) !== TRUE) {
        throw new Exception("Error in pemasukan query: " . $connect->error);
      }

      // Query untuk tabel jurnal
      $sql2 = "INSERT INTO jurnal (tgl_transaksi, jumlah, uraian, pos_debit, pos_kredit) 
               VALUES ('$tgl_transaksi', '$jumlah', '$uraian', '$pos_debit', '$pos_kredit')";

      if ($connect->query($sql2) !== TRUE) {
        throw new Exception("Error in jurnal query: " . $connect->error);
      }

      // Commit transaksi jika kedua query berhasil
      $connect->commit();
      $success = true;
    } catch (Exception $e) {
      // Rollback transaksi jika ada error
      $connect->rollback();
      $error = true;
      $errorText = $e->getMessage();
    }
  }
}
?>

<div class="row">
  <div class="col-12 col-md-6">
    <a class="btn btn-success" href="?page=pemasukan"><i class="fa fa-arrow-left"></i> Kembali</a>
  </div>
</div><br>

<form method="POST" enctype="multipart/form-data">
  <div class="row">
    <div class="col-lg-12 mb-9">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Transaksi Masuk</h6>
      </div>

      <div class="modal-body">
        <div class="form-group">
          <label>Tanggal Transaksi :</label>
          <input type="date" class="form-control" name="tgl_transaksi" required style="max-width: 200px;">
        </div>
        <div class="form-group">
          <label>Nilai Transaksi :</label>
          <input type="text" class="form-control" name="jumlah" id="jumlah" required style="max-width: 200px;">
        </div>
        <div class="form-group">
          <label>Uraian :</label>
          <textarea name="uraian" id="uraian" class="form-control" required></textarea>
        </div>
        <div class="form-group">
          <label>Pos Debit :</label>
          <select class="form-control" name="pos_debit" required style="max-width: 350px">
            <option value=""></option>
            <?php while ($row = $result_pos_debit->fetch_assoc()): ?>
              <?php if ($row['sub1_akun'] != 0): ?>
              <option value="<?= $row['id']; ?>"> <!-- value adalah id -->
                <?= $row['nama_akun']; ?> <!-- yang ditampilkan adalah nama_akun -->
              </option>
              <?php endif; ?>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Pos Kredit :</label>
          <select class="form-control" name="pos_kredit" required style="max-width: 350px">
            <option value=""></option>
            <?php while ($row = $result_pos_kredit->fetch_assoc()): ?>
              <?php if ($row['sub1_akun'] != 0): ?>
              <option value="<?= $row['id']; ?>"> <!-- value adalah id -->
                <?= $row['nama_akun']; ?> <!-- yang ditampilkan adalah nama_akun -->
              </option>
              <?php endif; ?>
            <?php endwhile; ?>
          </select>
        </div>

      </div>
    </div>
    <div class="form-group">
      <button type="submit" name="simpan" href="?page=pemasukan" class="btn btn-primary" style="background-color: darkcyan;">Simpan</button>
    </div>
  </div>
  </div>
</form>

<!-- Tambahkan SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  // Cek apakah ada sukses dari PHP
  <?php if ($success): ?>
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Data berhasil ditambahkan.',
      showConfirmButton: false,
      timer: 1500
    }).then(function() {
      window.location = '?page=pemasukan'; // Redirect setelah SweetAlert ditutup
    });
  <?php elseif ($error): ?>
    Swal.fire({
      icon: 'error',
      title: 'Gagal!',
      text: '<?php echo $errorText; ?>'
    });
  <?php endif; ?>
</script>

<script>
  document.getElementById('jumlah').addEventListener('input', function(e) {
    var value = e.target.value;
    value = value.replace(/[^0-9]/g, '');
    value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    e.target.value = value;
  });
</script>