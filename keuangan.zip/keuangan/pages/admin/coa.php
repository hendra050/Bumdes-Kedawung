<?php
include('./config/db.php');

// Menangani pengiriman formulir
$successStatus = false;
$successText = "";
$errorStatus = false;
$errorText = "";

// Proses jika tombol 'update_pencapaian' ditekan
if (isset($_POST['update_pencapaian'])) {
    $id_akun = $_POST['id_akun'];
    $pencapaian = str_replace('.', '', $_POST['pencapaian']);
    $pos = $_POST['pos'];

    // Validasi apakah semua input sudah diisi
    if (!empty($id_akun) && !empty($pencapaian) && !empty($pos)) {
        // Periksa apakah data untuk akun tersebut sudah ada di coa
        $query_check = "SELECT COUNT(*) as count FROM coa WHERE id_akun = ?";
        $stmt_check = $connect->prepare($query_check);
        $stmt_check->bind_param("i", $id_akun);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $data_check = $result_check->fetch_assoc();

        if ($data_check['count'] > 0) {
            // Data ada, lakukan update
            $query_update = "UPDATE coa SET pencapaian = ?, pos = ? WHERE id_akun = ?";
            $stmt_update = $connect->prepare($query_update);
            $stmt_update->bind_param("isi", $pencapaian, $pos, $id_akun);
        } else {
            // Data tidak ada, lakukan insert
            $query_insert = "INSERT INTO coa (id_akun, pencapaian, pos) VALUES (?, ?, ?)";
            $stmt_update = $connect->prepare($query_insert);
            $stmt_update->bind_param("iss", $id_akun, $pencapaian, $pos);
        }

        // Eksekusi query dan periksa hasil
        if ($stmt_update->execute()) {
            $successStatus = true;
            $successText = "Data berhasil disimpan.";
        } else {
            $errorStatus = true;
            $errorText = "Error: " . $connect->error;
        }
    } else {
        $errorStatus = true;
        $errorText = "Semua kolom harus diisi.";
    }
}

// Proses jika tombol 'delete' ditekan
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_POST['id_akun'])) {
    $id_akun = $_POST['id_akun'];

    // Cek apakah akun digunakan dalam transaksi di tabel jurnal
    $query_check = "SELECT COUNT(*) AS jumlah FROM jurnal WHERE pos_debit = ? OR pos_kredit = ?";
    $stmt_check = $connect->prepare($query_check);
    $stmt_check->bind_param("ii", $id_akun, $id_akun);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    $data_check = $result_check->fetch_assoc();

    if ($data_check['jumlah'] > 0) {
        // Jika data sudah digunakan di tabel jurnal
        $errorStatus = true;
        $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
    } else {
        // Jika belum digunakan, coba eksekusi penghapusan
        $query_delete = "DELETE FROM coa WHERE id_akun = ?";
        $stmt_delete = $connect->prepare($query_delete);
        $stmt_delete->bind_param("i", $id_akun);

        if ($stmt_delete->execute()) {
            // Cek apakah data benar-benar terhapus
            if ($stmt_delete->affected_rows > 0) {
                $successStatus = true;
                $successText = "Data berhasil dihapus!";
            } else {
                $errorStatus = true;
                $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
                // $errorText = "Gagal menghapus data.";
            }
        } else {
            // Jika query gagal dijalankan
            $errorStatus = true;
            $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
            // $errorText = "Gagal menghapus data.";
        }
    }

    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_POST['id_akun'])) {
        $id_akun = $_POST['id_akun'];

        // Cek apakah id akun ada dalam daftar yang tidak dapat dihapus
        $restricted_ids = [100, 400, 500, 600]; // Daftar ID akun yang tidak dapat dihapus
        if (in_array($id_akun, $restricted_ids)) {
            $errorStatus = true;
            $errorText = "Akun dengan ID $id_akun tidak dapat dihapus.";
        } else {
            // Cek apakah akun digunakan dalam transaksi di tabel jurnal
            $query_check = "SELECT COUNT(*) AS jumlah FROM jurnal WHERE pos_debit = ? OR pos_kredit = ?";
            $stmt_check = $connect->prepare($query_check);
            $stmt_check->bind_param("ii", $id_akun, $id_akun);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            $data_check = $result_check->fetch_assoc();

            if ($data_check['jumlah'] > 0) {
                // Jika data sudah digunakan di tabel jurnal
                $errorStatus = true;
                $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
            } else {
                // Jika belum digunakan, coba eksekusi penghapusan
                $query_delete = "DELETE FROM coa WHERE id_akun = ?";
                $stmt_delete = $connect->prepare($query_delete);
                $stmt_delete->bind_param("i", $id_akun);

                if ($stmt_delete->execute()) {
                    // Cek apakah data benar-benar terhapus
                    if ($stmt_delete->affected_rows > 0) {
                        $successStatus = true;
                        $successText = "Data berhasil dihapus!";
                    } else {
                        $errorStatus = true;
                        $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
                    }
                } else {
                    // Jika query gagal dijalankan
                    $errorStatus = true;
                    $errorText = "Akun ini sudah digunakan dalam transaksi dan tidak dapat dihapus.";
                }
            }
        }
    }
}

// Pagination setup
$batas = 10; // Jumlah item per halaman
$halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
$halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

$previous = $halaman - 1;
$next = $halaman + 1;

// Hitung total data
$query_total = "SELECT COUNT(*) as total FROM coa";
$result_total = mysqli_query($connect, $query_total);
$data_total = mysqli_fetch_assoc($result_total);
$jumlah_data = $data_total['total'];

// Hitung total halaman
$total_halaman = ceil($jumlah_data / $batas);

// Ambil data untuk halaman saat ini
$query = "SELECT id_akun, kode_akun, sub1_akun, sub2_akun, nama_akun, pencapaian, pos 
          FROM coa
          ORDER BY kode_akun, sub1_akun
          LIMIT $halaman_awal, $batas";
$result = mysqli_query($connect, $query);

// Query untuk menjumlahkan kolom `pencapaian` berdasarkan kode_akun
$query_sums = "SELECT kode_akun, SUM(pencapaian) as total_pencapaian
               FROM coa
               WHERE kode_akun IN (1, 4, 5, 6)
               GROUP BY kode_akun";
$result_sums = mysqli_query($connect, $query_sums);

$totals = [];
while ($row = mysqli_fetch_assoc($result_sums)) {
    $totals[$row['kode_akun']] = number_format($row['total_pencapaian'], 0, '.', '.');
}

// Akses hasil pencapaian per kode akun
$total_kode_akun_1 = isset($totals[1]) ? $totals[1] : 0;
$total_kode_akun_4 = isset($totals[4]) ? $totals[4] : 0;
$total_kode_akun_5 = isset($totals[5]) ? $totals[5] : 0;
$total_kode_akun_6 = isset($totals[6]) ? $totals[6] : 0;
?>

<!-- Tambahkan referensi SweetAlert2 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if ($successStatus): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?= $successText ?>',
                confirmButtonText: 'Ok'
            });
        <?php elseif ($errorStatus): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: '<?= $errorText ?>',
                confirmButtonText: 'Ok'
            });
        <?php endif; ?>
    });
</script>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead style="text-align:center; vertical-align: middle;">
            <h2>
                <center>Tabel COA</center>
            </h2>
            <div class="col-12 col-md-8 text-left">
                <a href="?page=coa&action=add" class="btn btn-primary" title='Tambah Akun'>Tambah Akun</a>
                <a href="pages/admin/export_coa_excel.php" class="btn btn-success" title='Export Excel'>
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
            </div><br>
            <tr>
                <th>ID Akun</th>
                <th>Nama Akun</th>
                <th>Target</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($data = mysqli_fetch_assoc($result)) {
                $id_akun = $data['id_akun'];
                $kode_akun = $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'];
                $nama_akun = $data['nama_akun'];
                $sub1_akun = $data['sub1_akun'];

                // Logika untuk menentukan pencapaian berdasarkan kode_akun
                if ($kode_akun == 100) {
                    $pencapaian = $total_kode_akun_1;
                } elseif ($kode_akun == 400) {
                    $pencapaian = $total_kode_akun_4;
                } elseif ($kode_akun == 500) {
                    $pencapaian = $total_kode_akun_5;
                } elseif ($kode_akun == 600) {
                    $pencapaian = $total_kode_akun_6;
                } else {
                    $pencapaian = isset($data['pencapaian']) ? number_format($data['pencapaian'], 0, '.', '.') : 0;
                }
            ?>
                <tr>
                    <td style="text-align: center;"><?= $kode_akun ?></td>
                    <td><?= $nama_akun ?></td>
                    <td style="text-align: right;"><?= $pencapaian ?></td>
                    <td>
                        <div style="display: flex; justify-content: center; gap: 10px;">
                            <?php if ($sub1_akun != 0): ?>
                                <a href="?page=coa&action=edit&id=<?= $id_akun ?>" class='btn btn-sm btn-primary' title='Ubah Akun'>
                                    <i class="fa fas fa-edit"></i>
                                </a>
                            <?php endif; ?>
                            <button type="button" class='btn btn-sm btn-danger btn-delete' data-id="<?= $id_akun ?>" title='Hapus Akun'>
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>


<!-- Pagination -->
<nav>
    <ul class="pagination justify-content-center">
        <li class="page-item">
            <a class="page-link" href='?page=coa&halaman=1'>&#8249;&#8249;</a>
        </li>
        <li class="page-item">
            <a class="page-link" <?php if ($halaman > 1) echo "href='?page=coa&halaman=$previous'"; ?>>
                <</a>
        </li>
        <?php
        $start = max(1, $halaman - 1);
        $end = min($halaman + 1, $total_halaman);
        for ($x = $start; $x <= $end; $x++) {
            $active = ($x == $halaman) ? 'active' : '';
            echo "<li class='page-item $active'><a class='page-link' href='?page=coa&halaman=$x'>$x</a></li>";
        }
        ?>
        <li class="page-item">
            <a class="page-link" <?php if ($halaman < $total_halaman) echo "href='?page=coa&halaman=$next'"; ?>>></a>
        </li>
        <li class="page-item">
            <a class="page-link" href='?page=coa&halaman=<?= $total_halaman; ?>'>&#8250;&#8250;</a>
        </li>
    </ul>
</nav>
</div>
</div>
</div>
</div>

<!-- SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('click', function(event) {
        if (event.target.closest('.btn-delete')) {
            event.preventDefault(); // Prevent default action

            var id_akun = event.target.getAttribute('data-id');

            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data ini akan dihapus dan tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '?page=coa&action=delete';

                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'id_akun';
                    input.value = id_akun;

                    form.appendChild(input);
                    document.body.appendChild(form);

                    form.submit();
                }
            });
        }
    });

    // Notifikasi sukses/gagal
    <?php if ($successStatus): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?= $successText; ?>',
            showConfirmButton: false,
            timer: 1500
        });
    <?php elseif ($errorStatus): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?= $errorText; ?>'
        });
    <?php endif; ?>
</script>