<?php
// Pastikan file db.php sudah di-include
require_once 'db.php';

// Inisialisasi variabel pencarian
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Inisialisasi variabel halaman
$halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
$batas = 5; // Jumlah data per halaman

// Query untuk menghitung total data anggota
if ($search) {
    // Jika ada pencarian, cari data dengan status 0 atau 1
    $query_count = "SELECT COUNT(*) as total FROM anggota WHERE (nama_lengkap LIKE '%$search%' OR id LIKE '%$search%') AND (status = 0 OR status = 1)";
} else {
    // Jika tidak ada pencarian, tampilkan hanya data dengan status 1
    $query_count = "SELECT COUNT(*) as total FROM anggota WHERE status = 1";
}

$result_count = mysqli_query($koneksi, $query_count);
$row_count = mysqli_fetch_assoc($result_count);
$total_data = $row_count['total'];

// Hitung total halaman
$total_halaman = ceil($total_data / $batas);

// Hitung offset
$offset = ($halaman - 1) * $batas;

// Query untuk mengambil data anggota
if ($search) {
    // Jika ada pencarian, ambil data dengan status 0 atau 1
    $query = "SELECT * FROM anggota WHERE (nama_lengkap LIKE '%$search%' OR id LIKE '%$search%') AND (status = 0 OR status = 1) ORDER BY id LIMIT $offset, $batas";
} else {
    // Jika tidak ada pencarian, ambil hanya data dengan status 1
    $query = "SELECT * FROM anggota WHERE status = 1 ORDER BY id LIMIT $offset, $batas";
}

$result = mysqli_query($koneksi, $query);

// Hitung nomor urut awal
$nomor_urut = ($halaman - 1) * $batas + 1;

// Pagination
$show_pages = 3; // Jumlah halaman yang ditampilkan
$start_page = max(1, min($halaman - 1, $total_halaman - $show_pages + 1));
$end_page = min($start_page + $show_pages - 1, $total_halaman);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggota Aktif</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-6xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold mb-6 text-center text-blue-600">Data Anggota Aktif</h1>
        
        <!-- Form Pencarian -->
        <form action="" method="GET" class="mb-6">
            <input type="hidden" name="page" value="buku_induk">
            <div class="flex">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Cari berdasarkan ID atau Nama" class="flex-grow p-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-400">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 transition duration-200">Cari</button>
            </div>
        </form>

        <!-- Tabel Data -->
        <div class="overflow-x-auto">
            <table class="w-full table-auto">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="px-4 py-2">No</th>
                        <th class="px-4 py-2">ID</th>
                        <th class="px-4 py-2">Nama Lengkap</th>
                        <th class="px-4 py-2">Email</th>
                        <th class="px-4 py-2">Tanggal Lahir</th>
                        <th class="px-4 py-2">Jenis Kelamin</th>
                        <th class="px-4 py-2">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr class="hover:bg-gray-100">
                            <td class="border px-4 py-2"><?php echo $nomor_urut++; ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($row['id']); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($row['email']); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($row['tgl_lahir']); ?></td>
                            <td class="border px-4 py-2"><?php echo $row['jenis_kelamin'] == 1 ? 'Laki-laki' : 'Perempuan'; ?></td>
                            <td class="border px-4 py-2"><?php echo $row['status'] == 1 ? 'Aktif' : 'Tidak Aktif'; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-6 flex justify-center items-center">
            <?php if ($halaman > 1) : ?>
                <a href="?page=buku_induk&halaman=<?php echo $halaman - 1; ?>&search=<?php echo urlencode($search); ?>" 
                   class="mx-1 px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200">
                    Previous
                </a>
            <?php endif; ?>

            <?php if ($start_page > 1) : ?>
                <span class="mx-1 px-3 py-2">...</span>
            <?php endif; ?>

            <?php for ($i = $start_page; $i <= $end_page; $i++) : ?>
                <a href="?page=buku_induk&halaman=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" 
                   class="mx-1 px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200 <?php echo $i == $halaman ? 'bg-blue-700' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>

            <?php if ($end_page < $total_halaman) : ?>
                <span class="mx-1 px-3 py-2">...</span>
            <?php endif; ?>

            <?php if ($halaman < $total_halaman) : ?>
                <a href="?page=buku_induk&halaman=<?php echo $halaman + 1; ?>&search=<?php echo urlencode($search); ?>" 
                   class="mx-1 px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200">
                    Next
                </a>
            <?php endif; ?>
        </div>
    </div>

    <script>
    // JavaScript untuk menangani perubahan halaman tanpa reload
    document.addEventListener('DOMContentLoaded', function() {
        const links = document.querySelectorAll('a[href^="?page=buku_induk"]');
        links.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.href;
                fetch(url)
                    .then(response => response.text())
                    .then(html => {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        const newContent = doc.querySelector('.max-w-6xl');
                        document.querySelector('.max-w-6xl').innerHTML = newContent.innerHTML;
                        history.pushState(null, '', url);
                    });
            });
        });
    });
    </script>
</body>
</html>