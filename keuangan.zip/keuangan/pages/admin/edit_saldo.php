<?php
include('./config/db.php');
// Masukkan file koneksi database

$error = false;
$errorText = "";
$success = false;

// Ambil ID data dari parameter URL, misal: edit.php?id=1
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Jika ID tidak ada, tampilkan pesan error
if ($id === null) {
    die("ID tidak ditemukan.");
}

// Ambil data dari tabel kode_akun berdasarkan ID
$sql = "SELECT id_akun, kode_akun, sub1_akun, sub2_akun, nama_akun, jumlah, pos 
          FROM saldo
        WHERE saldo.id_akun = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    die("Data tidak ditemukan.");
}

// Proses jika tombol simpan ditekan
if (isset($_POST['simpan'])) {
    $id_akun = $_POST['id_akun'];
    $jumlah = str_replace('.', '', $_POST['jumlah']);
    $pos = $_POST['pos'];

    // Validasi sederhana
    if (empty($id_akun) || empty($pos)) {
        $error = true;
        $errorText = "Semua kolom harus diisi.";
    } else {
        // Update data ke tabel saldo
        $sql = "UPDATE saldo SET jumlah = ?, pos = ? WHERE id_akun = ?";
        $stmt_update = $connect->prepare($sql);
        $stmt_update->bind_param("dsi", $jumlah, $pos, $id); // Gantilah $id_akun menjadi $id

        if ($stmt_update->execute()) {
            $success = true;  
        } else {
            $error = true;
            $errorText = "Error: " . $stmt_update->error; // Tampilkan error dari query update
        }
    }
}
?>

<div class="row">
    <div class="col-12 col-md-6">
        <a class="btn btn-success" href="?page=saldo"><i class="fa fa-arrow-left"></i> Kembali</a>
    </div>
</div><br>
<form method="POST">
    <div class="row">
        <div class="col-lg-12 mb-9">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Saldo Awal</h6>
            </div>

            <div class="modal-body">
                <label>ID Akun :</label>
                <input type="text" class="form-control" id="id_akun" name="id_akun"
                    value="<?php echo isset($data['kode_akun']) && isset($data['sub1_akun']) && isset($data['sub2_akun']) ? $data['kode_akun'] . $data['sub1_akun'] . $data['sub2_akun'] : ''; ?>"
                    required style="max-width: 200px;" readonly>

                <label>Nama Akun :</label>
                <input type="text" class="form-control"
                    value="<?php echo isset($data['nama_akun']) ? $data['nama_akun'] : ''; ?>"
                    readonly style="max-width: 250px;">

                <label>Jumlah :</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah"
                    value="<?php echo isset($data['jumlah']) ? number_format($data['jumlah'], 0, '.', '.') : ''; ?>"
                    required style="max-width: 250px;">

                <label>Pos :</label>
                <div>
                    <input type="radio" name="pos" value="debit" id="pos_debit" <?php echo (isset($data['pos']) && $data['pos'] == 'debit') ? 'checked' : ''; ?>> Debit
                    <input type="radio" name="pos" value="kredit" id="pos_kredit" <?php echo (isset($data['pos']) && $data['pos'] == 'kredit') ? 'checked' : ''; ?>> Kredit
                </div>
            </div>

            <div class="form-group">
                <button type="submit" name="simpan" class="btn btn-primary" style="background-color: darkcyan;">Simpan</button>
            </div>
        </div>
    </div>
</form>

<script>
    document.getElementById('jumlah').addEventListener('input', function(e) {
        var value = e.target.value;

        // Hapus semua karakter yang bukan angka
        value = value.replace(/[^0-9]/g, '');

        // Tambahkan pemisah ribuan (.)
        value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');

        // Update nilai input dengan format baru
        e.target.value = value;
    });
</script>

<!-- Tambahkan SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Cek apakah ada sukses dari PHP
    <?php if ($success): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: 'Data berhasil diedit.',
            showConfirmButton: false,
            timer: 1500
        }).then(function() {
            window.location = '?page=saldo'; // Redirect setelah SweetAlert ditutup
        });
    <?php elseif ($error): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?php echo $errorText; ?>'
        });
    <?php endif; ?>
</script>