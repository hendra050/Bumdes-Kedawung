<?php
include('../../config/db.php');

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=jurnal.xls");

$query = "SELECT 'jurnal' as type, id_jurnal as id, tgl_transaksi, uraian, pos_debit, pos_kredit, jumlah FROM jurnal ORDER BY id";
$result = mysqli_query($connect, $query);

echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
echo "<th>NO</th>";
echo "<th>TANGGAL</th>";
echo "<th>URAIAN</th>";
echo "<th>AKUN DEBIT</th>";
echo "<th>KODE AKUN DEBIT</th>";
echo "<th>AKUN KREDIT</th>";
echo "<th>KODE AKUN KREDIT</th>";
echo "<th>DEBET</th>";
echo "<th>KREDIT</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

$no = 1;
$total_debit = 0;
$total_kredit = 0;

// Fetch data dan tampilkan di tabel
while ($data = mysqli_fetch_assoc($result)) {
    $pos_debit = $data['pos_debit'];
    $pos_kredit = $data['pos_kredit'];

    // Query untuk mendapatkan detail akun debit dan kredit
    $query2 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_debit");
    $query3 = mysqli_query($connect, "SELECT kode_akun, sub1_akun, sub2_akun, nama_akun FROM kode_akun WHERE id = $pos_kredit");
    $data2 = $query2->fetch_assoc();
    $data3 = $query3->fetch_assoc();

    // Menambahkan total debit dan kredit
    $total_debit += $data['jumlah'];
    $total_kredit += $data['jumlah'];

    // Baris pertama untuk uraian, akun debit, dan jumlah debit
    echo "<tr>";
    echo "<td style='text-align: center;'>" . $no++ . "</td>";
    echo "<td style='text-align: center;'>" . date('d-m-Y', strtotime($data['tgl_transaksi'])) . "</td>";
    echo "<td>" . $data['uraian'] . "</td>";
    echo "<td>" . $data2['nama_akun'] . "</td>";
    echo "<td>" . $data2['kode_akun'] . $data2['sub1_akun'] . $data2['sub2_akun'] . "</td>";
    echo "<td></td>";  // Kosongkan untuk baris akun kredit
    echo "<td></td>";  // Kosongkan untuk kode akun kredit
    echo "<td style='text-align: right;'>" . number_format($data['jumlah'], 0, '.', '.') . "</td>";
    echo "<td></td>";  // Kosongkan untuk jumlah kredit
    echo "</tr>";

    // Baris kedua untuk akun kredit dan jumlah kredit
    echo "<tr>";
    echo "<td></td>";
    echo "<td></td>";
    echo "<td></td>";
    echo "<td></td>";  // Kosongkan untuk akun debit
    echo "<td></td>";  // Kosongkan untuk kode akun debit
    echo "<td>" . $data3['nama_akun'] . "</td>";
    echo "<td>" . $data3['kode_akun'] . $data3['sub1_akun'] . $data3['sub2_akun'] . "</td>";
    echo "<td></td>";  // Kosongkan untuk jumlah debit
    echo "<td style='text-align: right;'>" . number_format($data['jumlah'], 0, '.', '.') . "</td>";
    echo "</tr>";
}

echo "</tbody>";

// Menampilkan total di bagian footer
echo "<tfoot>";
echo "<tr>";
echo "<th colspan='7' style='text-align:right'>Total</th>";
echo "<th style='text-align: right;'>" . number_format($total_debit, 0, '.', '.') . "</th>";
echo "<th style='text-align: right;'>" . number_format($total_kredit, 0, '.', '.') . "</th>";
echo "</tr>";
echo "</tfoot>";

echo "</table>";
?>