<?php
include('./config/db.php'); // Masukkan file koneksi database

$error = false;
$success = false;  // Flag untuk sukses

if (isset($_POST['simpan'])) {
  $tgl_transaksi = $_POST['tgl_transaksi'];
  $jumlah = preg_replace('/\D/', '', $_POST['jumlah']);
  $uraian = $_POST['uraian'];
  $pos_debit = $_POST['pos_debit'];
  $pos_kredit = $_POST['pos_kredit'];

  // Validasi sederhana
  if (empty($tgl_transaksi) || empty($jumlah) || empty($uraian) || empty($pos_debit) || empty($pos_kredit)) {
    $error = true;
    $errorText = "Semua field harus diisi.";
  } else {
    $sql = "INSERT INTO jurnal (tgl_transaksi, jumlah, uraian, pos_debit, pos_kredit) 
            VALUES ('$tgl_transaksi', '$jumlah', '$uraian', '$pos_debit', '$pos_kredit')";

    if ($connect->query($sql) === TRUE) {
      $success = true;  // Set flag success ke true
    } else {
      $error = true;
      $errorText = "Error: " . $connect->error;
    }
  }
}
?>

<div class="row">
  <div class="col-12 col-md-6">
    <a class="btn btn-success" href="?page=jurnal"><i class="fa fa-arrow-left"></i> Kembali</a>
  </div>
</div><br>

<form method="POST" enctype="multipart/form-data">
  <div class="row">
    <div class="col-lg-12 mb-9">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Transaksi Masuk</h6>
      </div>
      <div class="form-group">
        <label>Tanggal Transaksi :</label>
        <input type="date" class="form-control" name="tgl_transaksi" required style="max-width: 200px;">
      </div>
      <div class="form-group">
        <label>Uraian :</label>
        <textarea name="uraian" id="uraian" class="form-control" required></textarea>
      </div>
      <div class="row">
        <div class="col-md-3">
          <div class="form-group">
            <label>Pos Debit :</label>
            <select name="pos_debit" class="form-control" required style="max-width: 280px;">
              <option></option>
              <option value="1">Kas</option>
              <option value="2">Kas Besar</option>
              <option value="3">Kas Kecil</option>
              <option value="4">Pendapatan</option>
              <option value="5">Pendapatan Penjualan</option>
              <option value="6">Pendapatan Hadiah</option>
              <option value="7">Belanja</option>
              <option value="8">Belanja Gaji</option>
              <option value="9">Belanja Barang</option>
              <option value="10">Biaya Usaha</option>
              <option value="11">Biaya Gaji</option>
              <option value="12">Biaya Gaji Bonus</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3">
          <div class="form-group">
            <label>Pos Kredit :</label>
            <select name="pos_kredit" class="form-control" required style="max-width: 280px;">
              <option></option>
              <option value="1">Kas</option>
              <option value="2">Kas Besar</option>
              <option value="3">Kas Kecil</option>
              <option value="4">Pendapatan</option>
              <option value="5">Pendapatan Penjualan</option>
              <option value="6">Pendapatan Hadiah</option>
              <option value="7">Belanja</option>
              <option value="8">Belanja Gaji</option>
              <option value="9">Belanja Barang</option>
              <option value="10">Biaya Usaha</option>
              <option value="11">Biaya Gaji</option>
              <option value="12">Biaya Gaji Bonus</option>
            </select>
          </div>
        </div>
      </div>
      <div class="col-md-4">
          <div class="form-group">
            <label>Nilai Transaksi :</label>
            <input type="text" name="jumlah" id="jumlah" class="form-control" required style="max-width: 280px;">
          </div>
        </div>
      <br>
      <div class="form-group">
        <button type="submit" name="simpan" href="?page=jurnal" class="btn btn-primary" style="background-color: darkcyan;">Simpan</button>
      </div>
</form>


<!-- Tambahkan SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  // Cek apakah ada sukses dari PHP
  <?php if ($success): ?>
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Data berhasil ditambahkan.',
      showConfirmButton: false,
      timer: 1500
    }).then(function() {
      window.location = '?page=jurnal'; // Redirect setelah SweetAlert ditutup
    });
  <?php elseif ($error): ?>
    Swal.fire({
      icon: 'error',
      title: 'Gagal!',
      text: '<?php echo $errorText; ?>'
    });
  <?php endif; ?>
</script>

<script>
  document.getElementById('jumlah').addEventListener('input', function(e) {
    var value = e.target.value;
    value = value.replace(/[^0-9]/g, '');
    value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    e.target.value = value;
  });
</script>
