<style>
    table {
        font-family: "Poppins", sans-serif;
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        padding: 5px;
        text-align: left;
        border: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
        font-weight: bold;
        text-align: center;
    }

    tbody tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tbody tr:nth-child(odd) {
        background-color: #ffffff;
    }

    .text-left {
        text-align: left;
    }
</style>

<h2>
    <center>Buku Kas</center>
</h2>

<?php
$kodeKas = [
    'Kas Besar' => '110',
    'Kas Kecil' => '120'
];

// Koneksi ke database
$connect = mysqli_connect('localhost', 'root', '', 'keuangan');

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

// Mengambil filter dari form
$filterTanggalMulai = isset($_POST['filter_tanggal_mulai']) ? $_POST['filter_tanggal_mulai'] : '';
$filterTanggalAkhir = isset($_POST['filter_tanggal_akhir']) ? $_POST['filter_tanggal_akhir'] : '';
$filterKodeKas = isset($_POST['filter_kode_kas']) ? $_POST['filter_kode_kas'] : '';

// Mendapatkan tanggal sehari sebelum tanggal mulai
$tanggalSebelumMulai = date('Y-m-d', strtotime($filterTanggalMulai . ' -1 day'));

// Menyiapkan query SQL
$where = '';

// Filter tanggal
if (!empty($filterTanggalMulai) && !empty($filterTanggalAkhir)) {
    $where .= "AND tgl_transaksi BETWEEN '$filterTanggalMulai' AND '$filterTanggalAkhir' ";
}

// Filter kode kas
if (!empty($filterKodeKas)) {
    $where .= "AND (
        ('$filterKodeKas' = 'Kas Besar' AND (pos_debit = '2' OR pos_kredit = '2')) OR
        ('$filterKodeKas' = 'Kas Kecil' AND (pos_debit = '3' OR pos_kredit = '3'))
    ) ";
}

// Jika filter tanggal mulai diisi, hitung saldo hingga sehari sebelum tanggal mulai yang dipilih
$saldo_sebelum = 0; // Inisialisasi default

if (!empty($filterTanggalMulai)) {
    // Query untuk saldo hingga sehari sebelum tanggal mulai
    $query_saldo_sebelum = "
        SELECT SUM(IF(pos_debit IN ('2', '3'), jumlah, 0)) - SUM(IF(pos_kredit IN ('2', '3'), jumlah, 0)) AS saldo_sebelum 
        FROM jurnal 
        WHERE tgl_transaksi < '$filterTanggalMulai'
    ";

    $result_saldo_sebelum = mysqli_query($connect, $query_saldo_sebelum);
    if ($result_saldo_sebelum) {
        $data_saldo_sebelum = mysqli_fetch_assoc($result_saldo_sebelum);
        $saldo_sebelum = $data_saldo_sebelum['saldo_sebelum'] ?? 0;
    } else {
        echo "Error in Query: " . mysqli_error($connect);
    }
}

// Query untuk mengambil data tanpa pagination
$sql = "
SELECT tgl_transaksi, uraian, pos_debit, pos_kredit, jumlah 
FROM jurnal
WHERE 1=1 $where
ORDER BY tgl_transaksi ASC";

$query = mysqli_query($connect, $sql);

if (!$query) {
    echo "<p>Error: " . mysqli_error($connect) . "</p>";
}

$saldo = $saldo_sebelum; // Awal saldo diambil dari saldo hingga tanggal mulai
?>

<!-- Displaying the form for filters -->
<form method="post" id="filterForm">
    <div class="row">
        <div class="col-md-2">
            <label for="filter_tanggal_mulai">Tanggal Awal</label>
            <input type="date" id="filter_tanggal_mulai" class="form-control" name="filter_tanggal_mulai" value="<?= htmlspecialchars($filterTanggalMulai) ?>">
        </div>
        <div class="col-md-2">
            <label for="filter_tanggal_akhir">Tanggal Akhir</label>
            <input type="date" id="filter_tanggal_akhir" class="form-control" name="filter_tanggal_akhir" value="<?= htmlspecialchars($filterTanggalAkhir) ?>">
        </div>
        <div class="col-md-2">
            <label for="filter_kode_kas">Pilih Akun Kas</label>
            <select class="form-control" name="filter_kode_kas">
                <option value="">Semua</option>
                <option value="Kas Besar" <?= $filterKodeKas == 'Kas Besar' ? 'selected' : '' ?>>Kas Besar</option>
                <option value="Kas Kecil" <?= $filterKodeKas == 'Kas Kecil' ? 'selected' : '' ?>>Kas Kecil</option>
            </select>
        </div>
        <div class="col-md-3">
            <br>
            <button type="submit" name="btn-cari" class="btn btn-primary">Cari</button>
            <a href="?page=kas" class="btn btn-secondary">Reset</a>
        </div>
    </div>
</form><br>

<!-- Table to display the data -->
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>TANGGAL</th>
            <th>URAIAN</th>
            <th>MASUK</th>
            <th>KELUAR</th>
            <th>SALDO</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (!empty($filterTanggalMulai)) :
        ?>
            <tr>
                <td></td>
                <td style="text-align: center; font-weight: bold;"><?= date('d-m-Y', strtotime($tanggalSebelumMulai)) ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td style="text-align: right; font-weight: bold;"><?= number_format($saldo_sebelum, 0, '.', '.') ?></td>
            </tr>
        <?php endif; ?>

        <?php
        $no = 1; // Pastikan nomor tetap dimulai dari 1
        while ($data = mysqli_fetch_assoc($query)) {
            // Logic untuk menghitung "MASUK" dan "KELUAR"
            $masuk = ($data['pos_debit'] == 2 || $data['pos_debit'] == 3) ? $data['jumlah'] : 0;
            $keluar = ($data['pos_kredit'] == 2 || $data['pos_kredit'] == 3) ? $data['jumlah'] : 0;

            // Menghitung saldo saat ini
            $saldo += $masuk - $keluar;
        ?>
            <tr>
                <td style="text-align: center;"><?= $no++; ?></td>
                <td style="text-align: center;"><?= date('d-m-Y', strtotime($data['tgl_transaksi'])) ?></td>
                <td><?= htmlspecialchars($data['uraian']) ?></td>
                <td style="text-align: right;"><?= number_format($masuk, 0, '.', '.') ?></td>
                <td style="text-align: right;"><?= number_format($keluar, 0, '.', '.') ?></td>
                <td style="text-align: right;"><?= number_format($saldo, 0, '.', '.') ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
